<?php 
session_start();
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_pekerjaan.php";
include "m_laporan.php";
$connection = new Database($host, $user, $pass, $database);
$laporan    = new laporan($connection);
$pekerjaan  = new Pekerjaan($connection);

	if (isset($_POST['Simpan'])) :
		$id_laporan                = $connection->conn->real_escape_string($_POST['Id_Laporan']);
		$id_pekerjaan              = $connection->conn->real_escape_string($_POST['Id_Pekerjaan']);
		$jumlah_barang             = $connection->conn->real_escape_string($_POST['Jumlah_Barang']);
		$permasalahan              = $connection->conn->real_escape_string($_POST['Permasalahan']);
		$solusi                    = $connection->conn->real_escape_string($_POST['Solusi']);
		$jumlah_barang_selesai     = $connection->conn->real_escape_string($_POST['Jumlah_Barang_Selesai']);
		$jumlah_barang_blm_selesai = $jumlah_barang-$jumlah_barang_selesai;



	    if ($jumlah_barang-$jumlah_barang_selesai<0) {
	    	echo"<script>
			    	alert('Jumlah barang yang dimasukan salah !! ')
			       	document.location.href='../views/teknisi/home_teknisi.php?page=membuat_laporan'
			 	</script>";
			 	die();
	    }else{

	    	$tambah=$laporan->Tambah_Laporan($id_laporan,$id_pekerjaan,$permasalahan,$solusi,$jumlah_barang_selesai,$jumlah_barang_blm_selesai);


		    if ($tambah>0){
		    	$update=$pekerjaan->Update_Jumlah_Pekerjaan($id_pekerjaan,$jumlah_barang_blm_selesai);
		    		if ($update!=1) {
		    			echo"<script>
				       			alert('Data pekerjaan gagal di update !!')
				       			document.location.href='../views/teknisi/home_teknisi.php?page=membuat_laporan'
				 	  		</script>";
		    		}
					echo" <script>
				       	alert('Data berhasil di simpan!!')
				       	document.location.href='../views/teknisi/home_teknisi.php?page=membuat_laporan'
				 	  </script>";
			}else{
				echo" <script>
				       	alert('Data Gagal di simpan!!')
				       	document.location.href='../views/teknisi/home_teknisi.php?page=membuat_laporan'
				 	  </script>";
			}

		}


	endif;

	


?>




