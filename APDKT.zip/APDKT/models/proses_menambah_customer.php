<?php
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_customer.php";
include "+function.php";
$connection = new Database($host, $user, $pass, $database); 
$customer   = new Customer($connection);
$data       = $customer->Cek_NM_Customer($_POST['Nama_Customer']);

$cek=mysqli_num_rows($data);
if ($cek>0){
	echo "<script>
		   	alert('Nama Customer telah ada !!')
		  	document.location.href='../views/admin/home_admin.php?page=menambah_customer'
		  </script>";
}else{
		$id_customer     = $connection->conn->real_escape_string($_POST['Id_Customer']);
		$nama_customer   = $connection->conn->real_escape_string($_POST['Nama_Customer']);
		$alamat_customer = $connection->conn->real_escape_string($_POST['Alamat_Customer']);
		$telp_customer   = $connection->conn->real_escape_string($_POST['Telp_Customer']);
		
    $tambah=$customer->Tambah_Customer($id_customer,$nama_customer,$alamat_customer,$telp_customer);

    echo Alert_Tambah($tambah,'admin','home_admin','mengelola_customer','menambah_customer');   
	
}



?>
