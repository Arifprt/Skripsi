<?php 

class Teknisi
{
	private $mysqli;

	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	public function Cek_Teknisi($username=null,$pass=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_teknisi";

		if ($username!=null and $pass!=null) {
				$sql .=" WHERE Username='$username' and Password='$pass'";
		}

		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tampil_Teknisi( $key=null, $pageawal=null, $pagejml=null ){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_Teknisi WHERE Level='teknisi'";

		if ( $key!=null and $pagejml==null) {
			$sql .=" AND Id_Teknisi LIKE '%$key%' OR 
							Username LIKE '%$key%' OR 
						   Nama LIKE '%$key%' OR
						   Level LIKE '%$key%' ";
		
		}else if ( $key!=null and  $pagejml!=null ) {
			$sql .=" AND Id_Teknisi LIKE '%$key%' OR
			 			Username LIKE '%$key%' OR 
						   Nama LIKE '%$key%' OR
						   Level LIKE '%$key%' 
						   LIMIT $pageawal, $pagejml";

		} else if ($key==null and $pagejml!=null ) {
			$sql .=" LIMIT $pageawal, $pagejml";
		}
		
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}
	

	public function Cari_Teknisi($key=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_teknisi";
		if ($key!=null) {
			$sql .=" WHERE Id_Teknisi = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tambah_Teknisi($id,$nama,$Username,$pass,$level){
		$db = $this->mysqli->conn;
		$db->query("INSERT INTO tbl_teknisi VALUES('$id','$nama','$Username','$pass','$level' )");
		 return mysqli_affected_rows($db);
	}

	public function Update_Teknisi($Id_Teknisi,$nama,$Username,$pass,$level){
		$db = $this->mysqli->conn;
		$db->query("UPDATE tbl_teknisi SET Nama='$nama', Username='$Username', Password='$pass', Level='$level' WHERE  Id_Teknisi='$Id_Teknisi'");

		return mysqli_affected_rows($db);		

	}

	public function Delete_Teknisi($nik){
		$db = $this->mysqli->conn;
		$db->query("DELETE FROM tbl_Teknisi WHERE Id_Teknisi='$nik'");

		return mysqli_affected_rows($db);		
	}

	public function Max_Id(){
		$db    = $this->mysqli->conn;
		$sql   = "SELECT max(Id_Teknisi) as maxId FROM tbl_Teknisi";
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}
	
} //end class

?>
