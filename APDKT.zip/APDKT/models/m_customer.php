<?php 

 
class Customer
{
	private $mysqli;

	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}


	public function Tambah_Customer($id_customer,$nama_customer,$alamat_customer,$telp_customer){
		$db = $this->mysqli->conn;
		$db->query("INSERT INTO tbl_customer VALUES('$id_customer','$nama_customer','$alamat_customer',
													'$telp_customer' )"); 
		 return mysqli_affected_rows($db);
	}

	public function Max_Id(){
		$db    = $this->mysqli->conn;
		$sql   = "SELECT max(Id_Cust) as maxId FROM tbl_customer";
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Cek_NM_Customer($nm_cust=null){
			$db  = $this->mysqli->conn;
			$sql = "SELECT * FROM tbl_customer";

			if ($nm_cust!=null) {
					$sql .=" WHERE Nama_Cust='$nm_cust' ";
			}

		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tampil_Customer( $key=null,$pageawal=null, $pagejml=null ){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_customer";
		if ( $key!=null and $pagejml==null ) {
			$sql .=" WHERE 	Id_Cust LIKE '%$key%' OR 
							Nama_Cust LIKE '%$key%' OR 
							Alamat_Cust LIKE '%$key%' OR
						   	Telp_Cust LIKE '%$key%' ";
		}
		if ($key!=null and $pagejml!=null) {
			$sql .=" WHERE 	Id_Cust LIKE '%$key%' OR 
							Nama_Cust LIKE '%$key%' OR 
							Alamat_Cust LIKE '%$key%' OR
						   	Telp_Cust LIKE '%$key%' 
						   	LIMIT $pageawal, $pagejml";
		}
		if ($key==null and $pagejml!=null) {
			$sql .= " LIMIT $pageawal, $pagejml";
		}
				
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	
	public function Cari_Customer($key=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_customer";
		if ($key!=null) {
				$sql .=" WHERE Id_Cust = '$key'";
		}
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Update_Customer($id_cust,$nama_cust,$alamat_cust,$telp_cust){
		$db = $this->mysqli->conn;
		$db->query("UPDATE tbl_customer SET Nama_Cust='$nama_cust', Alamat_Cust='$alamat_cust', Telp_Cust='$telp_cust' WHERE Id_Cust='$id_cust' ");

		return mysqli_affected_rows($db);		
	}

	public function Delete_Customer($nik){
		$db = $this->mysqli->conn;
		$db->query("DELETE FROM tbl_customer WHERE Id_Cust='$nik'");

		return mysqli_affected_rows($db);

	}


} // end class

?>
