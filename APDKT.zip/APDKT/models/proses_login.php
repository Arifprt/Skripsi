<?php 
include_once "+function.php";
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_teknisi.php";

$connection = new Database($host, $user, $pass, $database);
$user       = new Teknisi($connection);

$username   = $_POST['Username'];
$password   = $_POST['Password'];

$data       = $user->Cek_Teknisi($username, $password);
							

	if (mysqli_num_rows($data)===1) {
		$cek=$data->fetch_object();
		
		if ($cek->Level=='teknisi') {		
			$_SESSION["login"] = true;
			$_SESSION["user"]  = $cek->Id_Teknisi;
			$_SESSION["level"] = $cek->Level;
			header("location:../views/teknisi/home_teknisi.php");			
		}
		else if ($cek->Level=='admin') {
			$_SESSION["login"] = true;
			$_SESSION["user"]  = $cek->Username;
			$_SESSION["level"] = $cek->Level;
			header("location:../views/admin/home_admin.php");

		}
		else if ($cek->Level=='direktur') {
			$_SESSION["login"] = true;
			$_SESSION["user"]  = $cek->Username;
			$_SESSION["level"] = $cek->Level;
			header("location:../views/direktur/home_direktur.php");

		}
		
	}
	else{
		echo "<script>
		        alert('Username atau Password anda salah !!')
		        document.location.href='../index.php'
		       </script>";
		}

 ?>