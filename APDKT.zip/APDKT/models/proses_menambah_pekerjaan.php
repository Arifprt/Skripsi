<?php
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_pekerjaan.php";
include_once "+function.php";
$connection = new Database($host, $user, $pass, $database); 

$pekerjaan  = new Pekerjaan($connection);

	if (isset($_POST['Simpan'])) :
		$id_pekerjaan      = $connection->conn->real_escape_string($_POST['Id_Pekerjaan']);
		$tanggal_pekerjaan = $connection->conn->real_escape_string($_POST['Tanggal_Pekerjaan']);
		$nama_customer     = $connection->conn->real_escape_string($_POST['Nama_Customer']);
		$nama_barang       = $connection->conn->real_escape_string($_POST['Nama_Barang']);
		$teknisi           = $connection->conn->real_escape_string($_POST['Teknisi']);
		$jumlah_barang     = $connection->conn->real_escape_string($_POST['Jumlah_Barang']);

		
		$tambah            = $pekerjaan->Tambah_Pekerjaan($id_pekerjaan,$tanggal_pekerjaan,$nama_customer,
															$nama_barang,$teknisi,$jumlah_barang);

	    echo Alert_Tambah($tambah,'admin','home_admin','mengelola_pekerjaan','menambah_pekerjaan');


	endif;	


?>