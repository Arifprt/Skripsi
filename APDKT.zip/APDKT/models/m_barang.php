<?php 

class Barang 
{
	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	public function Tambah_Barang($id_brg,$nama_brg){
		$db = $this->mysqli->conn;
		$db->query("INSERT INTO tbl_barang VALUES('$id_brg','$nama_brg')");		 
		return mysqli_affected_rows($db);
	}


	public function Max_Id(){
		$db    = $this->mysqli->conn;
		$sql   = "SELECT max(Id_Barang) as maxId FROM tbl_barang";
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Cek_NM_Barang($nm_brg=null){
			$db  = $this->mysqli->conn;
			$sql = "SELECT * FROM tbl_barang";

			if ($nm_brg!=null) {
					$sql .=" WHERE Nama_Barang='$nm_brg' ";
			}

			$query= $db->query($sql) or die ($db->error);
			return $query;
	}

	public function Tampil_Barang( $key=null,$pageawal=null, $pagejml=null ){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_barang";

		if ( $key!=null and $pagejml==null ) {
			$sql .=" WHERE Id_Barang LIKE '%$key%' OR 
						   Nama_Barang LIKE '%$key%'";
		}
		 if ($key!=null and $pagejml!=null) {
		 	$sql .=" WHERE Id_Barang LIKE '%$key%' OR 
						   Nama_Barang LIKE '%$key%' 
						   LIMIT $pageawal, $pagejml";
		 }
		 if ($key==null and $pagejml!=null) {
		 	$sql .= " LIMIT $pageawal, $pagejml";		 
		 }		
		
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	
	public function Cari_Barang($key=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_barang";
		if ($key!=null) {
				$sql .=" WHERE Id_Barang = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}
	
	public function Update_Barang($id_barang,$nama_barang){
		$db = $this->mysqli->conn;
		$db->query("UPDATE tbl_barang SET Nama_Barang='$nama_barang'
					WHERE Id_Barang='$id_barang' ");
		
		return mysqli_affected_rows($db);

	}

	public function Delete_Barang($nik){
		$db = $this->mysqli->conn;
		$db->query("DELETE FROM tbl_barang WHERE Id_Barang='$nik'");

		return mysqli_affected_rows($db);

	}


	

} //end class
?>