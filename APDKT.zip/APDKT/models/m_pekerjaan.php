<?php 

class Pekerjaan
{
	private $mysqli;
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	public function Tampil_Pekerjaan($user=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT tbl_pekerjaan.Id_Pekerjaan, tbl_pekerjaan.Tanggal_Pekerjaan, tbl_customer.Nama_Cust, tbl_barang.Nama_Barang, tbl_pekerjaan.Jumlah_Barang, tbl_pekerjaan.Id_Teknisi
			FROM tbl_teknisi INNER JOIN (tbl_customer INNER JOIN (tbl_barang INNER JOIN tbl_pekerjaan ON tbl_barang.Id_Barang = tbl_pekerjaan.Id_Barang) ON tbl_customer.Id_Cust = tbl_pekerjaan.Id_Cust) ON tbl_teknisi.Id_Teknisi = tbl_pekerjaan.Id_Teknisi";
		
		if ($user!=null) {
			$sql .=" WHERE tbl_teknisi.Id_Teknisi='$user'";
		}

		
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Max_Id($like=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT max(Id_Pekerjaan) as maxId FROM tbl_pekerjaan";
		if ($like!=null) {
			$sql .= " WHERE Id_Pekerjaan LIKE '$like%'";
		}
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tambah_Pekerjaan($Id_Pekerjaan,$Tanggal_Pekerjaan,$Nama_Cust,$Nama_Barang,$Id_Teknisi,$Jumlah_Barang){
		$db  = $this->mysqli->conn;
		$sql = "INSERT INTO tbl_pekerjaan values('$Id_Pekerjaan','$Tanggal_Pekerjaan','$Nama_Cust','$Nama_Barang','$Id_Teknisi','$Jumlah_Barang')";
		$query = $db->query($sql);

		return mysqli_affected_rows($db);

	}

	public function Tampil_Pekerjaan2($key=null,$pageawal=null,$pagejml=null){

		$db  = $this->mysqli->conn;
		$sql = "SELECT tbl_pekerjaan.Id_Pekerjaan, tbl_pekerjaan.Tanggal_Pekerjaan, tbl_customer.Nama_Cust, tbl_barang.Nama_Barang, tbl_pekerjaan.Jumlah_Barang, tbl_pekerjaan.Id_Teknisi,tbl_teknisi.Nama,tbl_teknisi.Username
			FROM tbl_teknisi INNER JOIN (tbl_customer INNER JOIN (tbl_barang INNER JOIN tbl_pekerjaan ON tbl_barang.Id_Barang = tbl_pekerjaan.Id_Barang) ON tbl_customer.Id_Cust = tbl_pekerjaan.Id_Cust) ON tbl_teknisi.Id_Teknisi = tbl_pekerjaan.Id_Teknisi";

		if ( $key!=null and $pagejml==null) {
			$sql .=" WHERE 	tbl_customer.Nama_Cust LIKE '%$key%' OR 
							tbl_barang.Nama_Barang LIKE '%$key%' OR 
							tbl_teknisi.Id_Teknisi LIKE '%$key%' OR
							tbl_pekerjaan.Id_Pekerjaan LIKE '%$key%' OR
						   	tbl_pekerjaan.Tanggal_Pekerjaan LIKE '%$key%' OR
						   	tbl_teknisi.Username LIKE '%$key%'";
		}

		if ($key!=null and $pagejml!=null) {
			$sql.=" WHERE 	tbl_customer.Nama_Cust LIKE '%$key%' OR 
						tbl_barang.Nama_Barang LIKE '%$key%' OR 
						tbl_teknisi.Id_Teknisi LIKE '%$key%' OR
						tbl_pekerjaan.Id_Pekerjaan LIKE '%$key%' OR
						tbl_pekerjaan.Tanggal_Pekerjaan LIKE'%$key%' OR
						tbl_teknisi.Username LIKE'%$key%' 
						LIMIT $pageawal, $pagejml";

		}

		if ($key== null and $pagejml!= null) {

			$sql.=" LIMIT $pageawal, $pagejml"; 
		}
				
		$query = $db->query($sql) or die ($db->error);
		return $query;
	
	}

	public function Tampil_Pekerjaan_Utk_Teknisi($user,$jml_brg){
		$db  = $this->mysqli->conn;
		$sql ="SELECT tbl_pekerjaan.Id_Pekerjaan, tbl_pekerjaan.Tanggal_Pekerjaan, tbl_customer.Nama_Cust, tbl_barang.Nama_Barang, tbl_pekerjaan.Jumlah_Barang, tbl_pekerjaan.Id_Teknisi
			FROM tbl_teknisi INNER JOIN (tbl_customer INNER JOIN (tbl_barang INNER JOIN tbl_pekerjaan ON tbl_barang.Id_Barang = tbl_pekerjaan.Id_Barang) ON tbl_customer.Id_Cust = tbl_pekerjaan.Id_Cust) ON tbl_teknisi.Id_Teknisi = tbl_pekerjaan.Id_Teknisi WHERE tbl_teknisi.Id_Teknisi='$user' AND tbl_pekerjaan.Jumlah_Barang> '$jml_brg' ";
		
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	

	public function Cari_Pekerjaan($nik){
		$db  = $this->mysqli->conn;
		$sql = "SELECT tbl_pekerjaan.Id_Pekerjaan, tbl_pekerjaan.Tanggal_Pekerjaan, tbl_customer.Id_Cust, tbl_customer.Nama_Cust, tbl_barang.Nama_Barang, tbl_pekerjaan.Jumlah_Barang, tbl_pekerjaan.Id_Teknisi,tbl_teknisi.Nama
			FROM tbl_teknisi INNER JOIN (tbl_customer INNER JOIN (tbl_barang INNER JOIN tbl_pekerjaan ON tbl_barang.Id_Barang = tbl_pekerjaan.Id_Barang) ON tbl_customer.Id_Cust = tbl_pekerjaan.Id_Cust) ON tbl_teknisi.Id_Teknisi = tbl_pekerjaan.Id_Teknisi WHERE tbl_pekerjaan.Id_Pekerjaan='$nik'";
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}


	public function Update_Pekerjaan($nik, $tgl_pekerjaan, $id_cust, $id_barang, $teknisi, $jml_brg){
		$db = $this->mysqli->conn;
		$sql = "UPDATE `tbl_pekerjaan` SET `Tanggal_Pekerjaan` = '$tgl_pekerjaan', `Id_Cust` = '$id_cust', `Id_Barang` = '$id_barang', `Id_Teknisi` = '$teknisi', `Jumlah_Barang` = '$jml_brg' WHERE `tbl_pekerjaan`.`Id_Pekerjaan` = '$nik'";

		$query = $db->query($sql);		

		return mysqli_affected_rows($db);

	}
	public function Update_Jumlah_Pekerjaan($nik, $jml_brg){
		$db  = $this->mysqli->conn;
		$sql = "UPDATE `tbl_pekerjaan` SET  `Jumlah_Barang` = '$jml_brg' WHERE 
				`tbl_pekerjaan`.`Id_Pekerjaan` = '$nik'";

		$query = $db->query($sql);

		return mysqli_affected_rows($db);

	}


	public function Delete_Pekerjaan($nik){
		$db    = $this->mysqli->conn;
		$sql   = "DELETE FROM `tbl_pekerjaan` WHERE `Id_Pekerjaan` = '$nik'";
		$query = $db->query($sql);

		return mysqli_affected_rows($db);
	}


} // end class

?>