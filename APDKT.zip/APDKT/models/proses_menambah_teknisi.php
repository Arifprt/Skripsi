<?php
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_teknisi.php";
include_once "+function.php";
$connection = new Database($host, $user, $pass, $database); 
$teknisi       = new Teknisi($connection);

   if (@$_POST['Simpan']) {
   		$id_teknisi       = $connection->conn->real_escape_string($_POST['Id_Teknisi']);
		$nama_teknisi     = $connection->conn->real_escape_string($_POST['Nama_Teknisi']);
		$username_teknisi = $connection->conn->real_escape_string($_POST['Username']);
		$pass_teknisi     = $connection->conn->real_escape_string($_POST['Password']);
		$level_teknisi    = $connection->conn->real_escape_string($_POST['Level']);
		
		$db            = $teknisi->Tambah_Teknisi($id_teknisi,$nama_teknisi,$username_teknisi,$pass_teknisi,$level_teknisi);

        echo Alert_Tambah($db,'admin','home_admin','mengelola_teknisi','menambah_teknisi'); 
    }

 ?> 
