<?php
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_barang.php";
include "+function.php";

$connection = new Database($host, $user, $pass, $database); 
$barang     = new Barang($connection);
$data       = $barang->Cek_NM_Barang($_POST['Nama_Barang']);

$cek        = mysqli_num_rows($data);

	if ($cek>0){
		echo "<script>
			   	alert('Nama Barang telah ada !!')
			  	document.location.href='../views/admin/home_admin.php?page=menambah_barang'
			  </script>";
	}else{

		$id_barang   = $connection->conn->real_escape_string($_POST['Id_Barang']);
		$nama_barang = $connection->conn->real_escape_string($_POST['Nama_Barang']);
		
		$tambah      = $barang->Tambah_Barang($id_barang,$nama_barang);

	    echo Alert_Tambah($tambah,'admin','home_admin','mengelola_barang','menambah_barang');  
		
	}



?>
