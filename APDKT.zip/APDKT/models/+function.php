<?php 
session_start();

function Cek_Login($lvl,$login,$level){
	if ( !isset($login)) {
		header("location:../../index.php");
		exit;
		
	}
	if ($level!=$lvl) {
		header("location:../../index.php");
		exit;
	}
	
}

function Alert_Tambah($tambah,$folder,$nama_file,$nama_page_sukses,$nama_page_gagal){
	if ($tambah>0){
			$script = "<script>
		           		alert('Data berhasil di simpan!!')
		           		document.location.href='../views/$folder/$nama_file.php?page=$nama_page_sukses'
		          	  </script>";
		}else{
			$script = "<script>
		           		alert('Data Gagal di simpan!!')
		           		document.location.href='../views/$folder/$nama_file.php?page=$nama_page_gagal'
		          	  </script>";
		}
		return $script; 
}

function Alert_Hapus($hapus,$nama_file,$nama_page){
	 	if ($hapus>0){
			$script = "<script>
		           		alert('Data berhasil di Hapus!!')
		           		document.location.href='$nama_file.php?page=$nama_page'
		          	  </script>";
		}else{
			$script = "<script>
			           	alert('Data gagal di Hapus!!')
			           	document.location.href='$nama_file.php?page=$nama_page'
					   </script>";
		}
		return $script;
    }

function Alert_Ubah($ubah,$nama_file,$nama_page,$nama_page_gagal,$p,$id){
	if ($ubah>0){
			$script = "<script>
		           		alert('Data berhasil di ubah!!')
		           		document.location.href='$nama_file.php?page=$nama_page'
		          	   </script>";
		}else{
			$script = "<script>
		           		alert('Data gagal di ubah!!')
		           		document.location.href='$nama_file.php?page=$nama_page_gagal&p=$p&Id=$id'
		          	   </script>";
			}
	return $script;
}

function Max_ID($sql,$awal_char,$bnyk_char,$char){
	$data   = $sql-> fetch_object();
	$ID     = $data->maxId;
	$noUrut = (int) substr($ID, $awal_char, $bnyk_char); //1 , 5
	$noUrut++;
	$ID     = $char . sprintf("%05s", $noUrut);
	return $ID;
}

function Max_ID2($sql,$awal_char,$bnyk_char,$char){
	$data   = $sql-> fetch_object();
	$ID     = $data->maxId;
	$noUrut = (int) substr($ID, $awal_char, $bnyk_char); //0 , 5
	$noUrut++;
	$tgl    = Pecah_Tgl();
	$ID     = $char . $tgl . sprintf("%03s", $noUrut);
	return $ID;
}

function Pecah_Tgl(){
	$date         = date("m.d.y");
	$explode_date = explode(".", $date);
	$ed           = $explode_date[2] . $explode_date[0];
	return $ed;
}

function Tampil_Tanggal($tgl){
	$date     = (explode("-", $tgl));
	$arr_date = array($date[2],$date[1],$date[0]);
	$date     = (implode("-", $arr_date));
	return $date;
}

function Hapus_Session(){
		$_SESSION['key']       = [];
		$_SESSION['tgl_awal']  = [];
		$_SESSION['tgl_akhir'] = []; 
}

 ?>