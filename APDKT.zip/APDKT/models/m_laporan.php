<?php 

class Laporan
{
	private $mysqli;
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	

	public function Max_Id($like=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT max(Id_Laporan) as maxId FROM tbl_laporan";
		if ($like!=null) {
			$sql .= " WHERE Id_Laporan LIKE '$like%'";
		}
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}


	public function Tambah_Laporan($Id_Laporan,$Id_Pekerjaan,$Problem,$Solusi,$Jumlah_Barang_Selesai,$Jumlah_Barang_Blm_Selesai){
		$db  = $this->mysqli->conn;
		$sql = "INSERT INTO tbl_laporan values('$Id_Laporan','$Id_Pekerjaan',now(),'$Problem','$Solusi','$Jumlah_Barang_Selesai',$Jumlah_Barang_Blm_Selesai)";
		$query = $db->query($sql);

		return mysqli_affected_rows($db);

	}

	public function Tampil_Laporan($key=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_laporan";

		if ($key!=null ) {
			$sql.=" WHERE Id_Laporan LIKE '%$key%' OR
							Nama_Cust LIKE '%$key%' OR
							Nama_Barang LIKE '%$key%' OR
							Usernama LIKE '%$key%' OR
							Problem LIKE '%$key%' OR
							Solusi LIKE '%$key%' ";
		}

		$query = $db->query($sql);
		return $query;

	}

public function Tampil_Laporan_Admin($key=null, $tgl_awal=null, $tgl_akhir=null,
									$awal_data=null, $jml_halaman=null, $group=null,
									$k_cust=null, $d_akhir=null, $order=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT tbl_laporan.Id_Laporan, tbl_laporan.Id_Pekerjaan, tbl_customer.Nama_Cust, 
					tbl_barang.Nama_Barang, tbl_pekerjaan.Jumlah_Barang, tbl_teknisi.Id_Teknisi,
					 tbl_laporan.Tgl_Laporan,tbl_laporan.Problem, tbl_laporan.Solusi, 
					 tbl_laporan.Jml_Brg_Selesai, 
					tbl_laporan.Jml_Brg_Blm_Selesai,tbl_teknisi.Nama, tbl_teknisi.Username
			FROM tbl_teknisi INNER JOIN ((tbl_customer INNER JOIN (tbl_barang INNER JOIN tbl_pekerjaan ON
			 tbl_barang.Id_Barang = tbl_pekerjaan.Id_Barang) ON tbl_customer.Id_Cust = tbl_pekerjaan.Id_Cust) 
			 INNER JOIN tbl_laporan ON tbl_pekerjaan.Id_Pekerjaan = tbl_laporan.Id_Pekerjaan) ON
			  tbl_teknisi.Id_Teknisi = tbl_pekerjaan.Id_Teknisi";

		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $k_cust==null){
			$sql .=" LIMIT $awal_data,$jml_halaman ";

		}

		if ($key==null AND  $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman==null AND $k_cust==null  AND $order==null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' ) ";

		}
		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust==null AND $d_akhir==null AND $order==null){
			$sql .=" WHERE tbl_teknisi.Id_Teknisi='$key'";

		}
		if ($key!=null AND $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman==null AND $k_cust==null AND $order==null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_teknisi.Id_Teknisi='$key'))
			 ";

		}

		if ($key==null AND  $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman!=null AND $k_cust==null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' ) LIMIT $awal_data,$jml_halaman ";

		}
		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $k_cust==null AND $d_akhir==null){
			$sql .=" WHERE tbl_teknisi.Id_Teknisi='$key' LIMIT $awal_data,$jml_halaman ";

		}
		if ($key!=null AND $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman!=null AND $k_cust==null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_teknisi.Id_Teknisi='$key')) LIMIT $awal_data,$jml_halaman ";

		}

		if ( $key==null AND $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $group!=null) {
			$sql .=" GROUP BY Nama_Cust";
		}

		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust!=null AND $d_akhir==null
			AND $order==null){
			$sql .=" WHERE tbl_customer.Nama_Cust='$k_cust'";
		}

		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust!=null AND $d_akhir==null AND $order==null ){
			$sql .=" WHERE tbl_teknisi.Id_Teknisi='$key' AND tbl_customer.Nama_Cust='$k_cust'";
		}	

		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $k_cust!=null AND $d_akhir==null){
			$sql .=" WHERE tbl_customer.Nama_Cust='$k_cust' LIMIT $awal_data,$jml_halaman ";
		}

		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $k_cust!=null AND $d_akhir==null){
			$sql .=" WHERE tbl_teknisi.Id_Teknisi='$key' AND tbl_customer.Nama_Cust='$k_cust' LIMIT $awal_data,$jml_halaman";
		}

		if ($key==null AND  $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman==null AND $k_cust!=null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_customer.Nama_Cust='$k_cust')) 
					";
		}

		if ($key==null AND  $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman!=null AND $k_cust!=null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_customer.Nama_Cust='$k_cust')) 
					LIMIT $awal_data,$jml_halaman";
		}

		if ($key!=null AND  $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman==null AND $k_cust!=null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_customer.Nama_Cust='$k_cust') AND (tbl_teknisi.Id_Teknisi='$key'))";
		}

		if ($key!=null AND  $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman!=null AND $k_cust!=null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_customer.Nama_Cust='$k_cust') AND (tbl_teknisi.Id_Teknisi='$key')) LIMIT $awal_data,$jml_halaman";
		}
// c
		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust==null 
			AND $d_akhir!=null){
			$sql .=" WHERE tbl_laporan.Tgl_Laporan IN (
              SELECT MAX(Tgl_Laporan) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND 
              tbl_laporan.Jml_Brg_Blm_Selesai IN (
              SELECT MIN(Jml_Brg_Blm_Selesai) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND tbl_teknisi.Id_Teknisi='$key'";

		}
		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $k_cust==null 
			AND $d_akhir!=null){
			$sql .=" WHERE tbl_laporan.Tgl_Laporan IN (
              SELECT MAX(Tgl_Laporan) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND 
              tbl_laporan.Jml_Brg_Blm_Selesai IN (
              SELECT MIN(Jml_Brg_Blm_Selesai) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND tbl_teknisi.Id_Teknisi='$key' LIMIT $awal_data,$jml_halaman";

		}

		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust!=null 
			AND $d_akhir!=null){
			$sql .=" WHERE tbl_laporan.Tgl_Laporan IN (
              SELECT MAX(Tgl_Laporan) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND 
              tbl_laporan.Jml_Brg_Blm_Selesai IN (
              SELECT MIN(Jml_Brg_Blm_Selesai) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND tbl_customer.Nama_Cust='$k_cust'";

		}
		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $k_cust!=null 
			AND $d_akhir!=null){
			$sql .=" WHERE tbl_laporan.Tgl_Laporan IN (
              SELECT MAX(Tgl_Laporan) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND 
              tbl_laporan.Jml_Brg_Blm_Selesai IN (
              SELECT MIN(Jml_Brg_Blm_Selesai) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND tbl_customer.Nama_Cust='$k_cust' LIMIT $awal_data,$jml_halaman";

		}

		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust!=null 
			AND $d_akhir!=null){
			$sql .=" WHERE tbl_laporan.Tgl_Laporan IN (
              SELECT MAX(Tgl_Laporan) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND 
              tbl_laporan.Jml_Brg_Blm_Selesai IN (
              SELECT MIN(Jml_Brg_Blm_Selesai) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND tbl_customer.Nama_Cust='$k_cust' 
              AND tbl_teknisi.Id_Teknisi='$key' ";

		}
		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $k_cust!=null 
			AND $d_akhir!=null){
			$sql .=" WHERE tbl_laporan.Tgl_Laporan IN (
              SELECT MAX(Tgl_Laporan) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND 
              tbl_laporan.Jml_Brg_Blm_Selesai IN (
              SELECT MIN(Jml_Brg_Blm_Selesai) FROM tbl_laporan GROUP BY Id_Pekerjaan) AND tbl_customer.Nama_Cust='$k_cust'
              AND tbl_teknisi.Id_Teknisi='$key' LIMIT $awal_data,$jml_halaman";

		}

		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust==null AND $d_akhir==null AND $order!=null){
			$sql .=" ORDER BY Nama";
		}
		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust==null AND $d_akhir==null AND $order!=null){
			$sql .=" WHERE tbl_teknisi.Id_Teknisi='$key' ORDER BY Nama";
		}

		if ($key==null AND  $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman==null AND $k_cust==null  AND $order!=null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' ) ORDER BY Nama ";
		}
	
		if ($key!=null AND $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman==null AND $k_cust==null AND $order!=null){
			$sql .=" WHERE (Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_teknisi.Id_Teknisi='$key'))ORDER BY Nama ";
		}

		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust!=null AND $d_akhir==null AND $order!=null){
			$sql .=" WHERE tbl_customer.Nama_Cust='$k_cust' ORDER BY Nama";
		}

		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $k_cust!=null AND $d_akhir==null AND $order!=null ){
			$sql .=" WHERE tbl_teknisi.Id_Teknisi='$key' AND tbl_customer.Nama_Cust='$k_cust' ORDER BY Nama";
		}	


		$query = $db->query($sql);
		return $query;

	}


	public function Laporan_NM_Teknisi($key=null, $tgl_awal=null, $tgl_akhir=null,$group=null, $k_cust=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT tbl_laporan.Id_Laporan, tbl_laporan.Id_Pekerjaan, 
					 tbl_laporan.Tgl_Laporan,tbl_teknisi.Nama,tbl_customer.Nama_Cust
			FROM tbl_teknisi INNER JOIN ((tbl_customer INNER JOIN (tbl_barang INNER JOIN tbl_pekerjaan ON
			 tbl_barang.Id_Barang = tbl_pekerjaan.Id_Barang) ON tbl_customer.Id_Cust = tbl_pekerjaan.Id_Cust) 
			 INNER JOIN tbl_laporan ON tbl_pekerjaan.Id_Pekerjaan = tbl_laporan.Id_Pekerjaan) ON
			  tbl_teknisi.Id_Teknisi = tbl_pekerjaan.Id_Teknisi";

			  if ($key==null AND $tgl_awal==null AND $tgl_akhir==null AND $group!=null AND $k_cust==null) {
			  	$sql.=" GROUP BY tbl_teknisi.Nama";
			  }
			  	if ($key==null AND  $tgl_awal!=null AND $tgl_akhir!=null  AND $group!=null AND $k_cust==null){
				$sql .=" WHERE (tbl_laporan.Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' ) GROUP BY tbl_teknisi.Nama ";
				}
			if ($key!=null AND  $tgl_awal!=null AND $tgl_akhir!=null  AND $group!=null AND $k_cust==null){
				$sql .=" WHERE (tbl_laporan.Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_teknisi.Id_Teknisi='$key')) GROUP BY tbl_teknisi.Nama  ";	
			}
			if ($key!=null AND $tgl_awal==null AND $tgl_akhir==null AND $group!=null AND $k_cust==null) {
			  	$sql.=" WHERE tbl_teknisi.Id_Teknisi='$key' GROUP BY tbl_teknisi.Nama";
			  }
			if ($key==null AND $tgl_awal==null AND $tgl_akhir==null AND $group!=null AND $k_cust!=null) {
			  	$sql.=" WHERE Nama_Cust='$k_cust' GROUP BY tbl_teknisi.Nama";
			 }
			 if ($key!=null AND $tgl_awal==null AND $tgl_akhir==null AND $group!=null AND $k_cust!=null) {
			  	$sql.=" WHERE tbl_teknisi.Id_Teknisi='$key' AND tbl_customer.Nama_Cust='$k_cust' GROUP BY tbl_teknisi.Nama";
			 }

			if ($key==null AND  $tgl_awal!=null AND $tgl_akhir!=null  AND $group!=null AND $k_cust!=null){
				$sql .=" WHERE (tbl_laporan.Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_customer.Nama_Cust='$k_cust')) GROUP BY tbl_teknisi.Nama  ";
			}

				if ($key!=null AND  $tgl_awal!=null AND $tgl_akhir!=null  AND $group!=null AND $k_cust!=null){
				$sql .=" WHERE (tbl_laporan.Tgl_Laporan BETWEEN '$tgl_awal' AND '$tgl_akhir' AND (tbl_customer.Nama_Cust='$k_cust') AND (tbl_teknisi.Id_Teknisi='$key')) GROUP BY tbl_teknisi.Nama  ";
			}






		$query = $db->query($sql);
		return $query;
	}


} //end class laporan

?>