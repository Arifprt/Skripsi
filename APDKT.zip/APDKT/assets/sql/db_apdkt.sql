-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2018 at 03:54 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_apdkt`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_barang`
--

CREATE TABLE `tbl_barang` (
  `Id_Barang` varchar(6) NOT NULL,
  `Nama_Barang` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_barang`
--

INSERT INTO `tbl_barang` (`Id_Barang`, `Nama_Barang`) VALUES
('B00001', 'SH IMK C15'),
('B00002', 'SH MK C15 B2'),
('B00003', 'SH MK C15 A2'),
('B00004', 'SH MK C20 B3'),
('B00005', 'SH IMK C15 F23'),
('B00006', 'AE Selenal NE66'),
('B00007', 'AE Polimatic'),
('B00008', 'AE D4'),
('B00009', 'Cobox Quantum'),
('B00010', 'Cobox Selenall NE33'),
('B00011', 'SH IMK C152');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `Id_Cust` varchar(6) NOT NULL,
  `Nama_Cust` varchar(75) NOT NULL,
  `Alamat_Cust` varchar(150) NOT NULL,
  `Telp_Cust` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`Id_Cust`, `Nama_Cust`, `Alamat_Cust`, `Telp_Cust`) VALUES
('C00001', 'PT. Sulindamills', 'Jl. HOS Cokrooamitoto Km. 51. No. 133. Kalijaya, Cibitung Bekasi', '021-8900533'),
('C00002', 'PT. Mulia Jaya Sejahtera Abadi Tektile', 'Jl. Praga. DS. Yosorejo pekalongan.', ' 0285 - 424693'),
('C00003', 'PT. Primayudha Mandirijaya', 'Desa ngadirejo, Kec. Ampel Boyolali', '0298-3272727'),
('C00004', 'PT. Goldentatex Indonesia Office', 'Jl. Griya Agung Blok O no. 86 Suter Agung Jakarta', '021-6410645'),
('C00005', 'PT. Tifiko', 'Jl. MH. Thamrin. Desa Panaunggan PO.BOX 485 Tangerang', '021-5397563'),
('C00006', 'PT. Royal Cotton Indonesia', 'Ds. Gintung Kerta Klari Karanang', '0267-431000'),
('C00007', 'PT. World Yamatex Spinning Mills', 'Jl. Dusun Walahar I, RT02/RW01 Kec Klari Karawang', '0267-432688'),
('C00008', 'PT. Dong-IL Indonesia', 'Bekasi Internasional Indsutrial Estate C-9 Lemah Abang Bekasi', '021-8972320'),
('C00009', 'PT. Mulia Spindo Mills', 'Jl. Raya Serang Km. 71 Cikande Serang', '0254-401136'),
('C00010', 'PT. Warna Unggul ', 'Jl. Raya Subang Km. 8, Desa Campakasari Purwakarta', '0264-202037');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_laporan`
--

CREATE TABLE `tbl_laporan` (
  `Id_Laporan` varchar(8) NOT NULL,
  `Id_Pekerjaan` varchar(8) NOT NULL,
  `Tgl_Laporan` date NOT NULL,
  `Problem` varchar(150) NOT NULL,
  `Solusi` varchar(150) NOT NULL,
  `Jml_Brg_Selesai` int(3) NOT NULL,
  `Jml_Brg_Blm_Selesai` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_laporan`
--

INSERT INTO `tbl_laporan` (`Id_Laporan`, `Id_Pekerjaan`, `Tgl_Laporan`, `Problem`, `Solusi`, `Jml_Brg_Selesai`, `Jml_Brg_Blm_Selesai`) VALUES
('L1808001', 'P1808002', '2018-08-25', 'tdk di ajd', 'gnti komponen', 10, 21),
('L1808002', 'P1808002', '2018-08-25', 'tidak motong', 'ganti komponen', 1, 20),
('L1808003', 'P1808005', '2018-08-27', 'tidak bisa motong', 'ganti komponen', 2, 12),
('L1808004', 'P1808004', '2018-08-27', 'motong motong', 'ganti komponen', 2, 28),
('L1808005', 'P1808002', '2018-08-28', 'motong-motong', 'ganti IC', 7, 13);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pekerjaan`
--

CREATE TABLE `tbl_pekerjaan` (
  `Id_Pekerjaan` varchar(8) NOT NULL,
  `Tanggal_Pekerjaan` date NOT NULL,
  `Id_Cust` varchar(6) NOT NULL,
  `Id_Barang` varchar(6) NOT NULL,
  `Id_Teknisi` varchar(6) NOT NULL,
  `Jumlah_Barang` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pekerjaan`
--

INSERT INTO `tbl_pekerjaan` (`Id_Pekerjaan`, `Tanggal_Pekerjaan`, `Id_Cust`, `Id_Barang`, `Id_Teknisi`, `Jumlah_Barang`) VALUES
('P1808002', '2018-08-25', 'C00004', 'B00007', 'T00001', 13),
('P1808004', '2018-08-27', 'C00003', 'B00003', 'T00002', 28),
('P1808005', '2018-08-27', 'C00004', 'B00006', 'T00003', 12),
('P1808006', '2018-08-27', 'C00006', 'B00005', 'T00003', 41),
('P1808007', '2018-08-27', 'C00002', 'B00002', 'T00001', 12),
('P1808008', '2018-08-27', 'C00006', 'B00002', 'T00001', 14);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teknisi`
--

CREATE TABLE `tbl_teknisi` (
  `Id_Teknisi` varchar(6) NOT NULL,
  `Nama` varchar(25) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Level` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_teknisi`
--

INSERT INTO `tbl_teknisi` (`Id_Teknisi`, `Nama`, `Username`, `Password`, `Level`) VALUES
('AD001', 'admin', 'admin', 'admin', 'admin'),
('DTR01', 'direktur', 'direktur', 'direktur', 'direktur'),
('T00001', 'Arif Prasetia', 'AR', 'AR1', 'teknisi'),
('T00002', 'Darmawan Prasetya', 'DR', 'DR1', 'teknisi'),
('T00003', 'Angga Gintara', 'AG', 'AG1', 'teknisi'),
('T00004', 'Panji Darma', 'PD', 'PD1', 'teknisi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`Id_Barang`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`Id_Cust`);

--
-- Indexes for table `tbl_laporan`
--
ALTER TABLE `tbl_laporan`
  ADD PRIMARY KEY (`Id_Laporan`),
  ADD KEY `Id_Pekerjaan` (`Id_Pekerjaan`);

--
-- Indexes for table `tbl_pekerjaan`
--
ALTER TABLE `tbl_pekerjaan`
  ADD PRIMARY KEY (`Id_Pekerjaan`),
  ADD KEY `Id_Barang` (`Id_Barang`),
  ADD KEY `Id_Cust` (`Id_Cust`),
  ADD KEY `Id_Teknisi` (`Id_Teknisi`);

--
-- Indexes for table `tbl_teknisi`
--
ALTER TABLE `tbl_teknisi`
  ADD PRIMARY KEY (`Id_Teknisi`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_laporan`
--
ALTER TABLE `tbl_laporan`
  ADD CONSTRAINT `tbl_laporan_ibfk_1` FOREIGN KEY (`Id_Pekerjaan`) REFERENCES `tbl_pekerjaan` (`Id_Pekerjaan`);

--
-- Constraints for table `tbl_pekerjaan`
--
ALTER TABLE `tbl_pekerjaan`
  ADD CONSTRAINT `tbl_pekerjaan_ibfk_1` FOREIGN KEY (`Id_Barang`) REFERENCES `tbl_barang` (`Id_Barang`),
  ADD CONSTRAINT `tbl_pekerjaan_ibfk_2` FOREIGN KEY (`Id_Cust`) REFERENCES `tbl_customer` (`Id_Cust`),
  ADD CONSTRAINT `tbl_pekerjaan_ibfk_3` FOREIGN KEY (`Id_Teknisi`) REFERENCES `tbl_teknisi` (`Id_Teknisi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
