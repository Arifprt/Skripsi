var url,href,
	link=document.querySelectorAll('.nav-link'); 



url = window.location.href.split('page=')
// 		url='admin';
// 	}else{

// 	url = window.location.href.split('page=')[1];
// 	url = url.split('_')[1];
// 	url = url.split(/&/)[0];
// 	}



// for (var i =0 ; i < link.length ; i++) {
// 	href = link[i].getAttribute('href');
// 	href = href.split('_')[1];

// 	if ( href==url ) {
// 		link[i].style.color='#007bff';
// 	}
// }