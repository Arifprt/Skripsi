<?php
session_start();
require_once("../../config/+koneksi.php");
require_once("../../models/database.php");
require_once('../../assets//html2pdf/html2pdf.class.php');
include "../../models/m_pekerjaan.php"; 
include "../../models/m_teknisi.php"; 
$connection= new Database($host, $user, $pass, $database);
$pekerjaan= new Pekerjaan($connection);
$teknisi= new Teknisi($connection);


$date=date('j-n-Y');
$idteknisi=$_SESSION['user'];




$source='
<style>
*{
	padding: 0; 
	margin: 0;

}
.container{
	
	width:750px;
	margin:10px auto;

}
.header-pdf{
	padding: 10px;
	text-align: center;
	font-size: 12px;
	border-bottom: 2px solid rgba(0,0,0,0.8);
	margin-bottom: 15px;
}

.conten-pdf{
	padding: 2px;
}


.conten-pdf-header{
	margin-bottom: 10px;
}
.conten-pdf-header h2{
	text-align: center;
	margin-bottom: 15px;
}

.conten-pdf-header p{
	font-size: 15px;
	padding: 3px;
}
.conten-table-pdf{
	text-align: center;
	padding: 10px;
}

.conten-table-pdf table{
	border: 1px solid black;
	border-radius: 2px;
	margin: auto;
	margin-top: 30px;
	font-size: 16px;
}

.conten-table-pdf table th{
	text-align: center;
	padding: 3px 4px;
	background-color: #ddd;
}

.conten-table-pdf table td{
	text-align: center;
	padding: 8px;
}


.conten-table-pdf table tr:nth-child(odd){
	background-color: red;
}


</style> ';


$source .= '
<page>
	<div class="container">
		<div class="header-pdf">
		<h1>Aplikasi Pengolah Data Kerja Teknisi<br>
		PT. Komponen Industri dan Teknologi</h1>	

		</div>

		<div class="conten-pdf">
			<div class="conten-pdf-header">
				<h2>Daftar Pekerjaan</h2>
				<p>Tanggal : '.$date.'</p>';
				$tampilnm= $teknisi->Cari_Teknisi($idteknisi);
				while ( $data = $tampilnm->fetch_object()) {;
	$source .=' <p>Nama : '.$data->Nama.'</p>';
				}
				
$source .='	
		</div>

			<div class="conten-table-pdf">
				<table width=>
					<tr>
						<th>NO</th>
						<th>ID Pekerjaan</th>
						<th>Tanggal</th>
						<th>Nama Customer</th>
						<th>Nama Barang</th>
						<th>Jumlah</th>
					</tr>';
					$no=1;					
          			$tampil= $pekerjaan->Tampil_Pekerjaan_Utk_Teknisi($idteknisi,0);
          			while ($data = $tampil->fetch_object()) {
          				$tgl_pekerjaan=(explode("-", $data->Tanggal_Pekerjaan));
						$arr_tgl_pekerjaan=array($tgl_pekerjaan[2],$tgl_pekerjaan[1],$tgl_pekerjaan[0]);
						$tgl_pekerjaan=(implode("-", $arr_tgl_pekerjaan));

			$source.= '<tr>
						<td>'.$no++.'.</td>
						<td>'.$data->Id_Pekerjaan.'</td>
						<td>'.$tgl_pekerjaan.'</td>
						<td>'.$data->Nama_Cust.'</td>
						<td>'.$data->Nama_Barang.'</td>
						<td>'.$data->Jumlah_Barang.'</td>
				</tr>';
					 }

		$source.='</table>
			</div>
		</div>
	</div>
</page>';

$html2pdf = new HTML2PDF('P', 'A4', 'en');
$html2pdf->setDefaultFont('Arial');
$html2pdf->writeHTML($source);
$html2pdf->Output('Pekerjaan - '.rand().'.pdf');

?>