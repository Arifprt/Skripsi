<?php
include_once "../../models/+function.php";
include "../../models/m_pekerjaan.php";
include "../../models/m_customer.php"; 

$pekerjaan = new Pekerjaan($connection);
$user      = $_SESSION['user'];
Cek_Login("teknisi",$_SESSION['login'],$_SESSION['level']);

$customer  = new Customer($connection);


// validasi halaman
$uri= $_SERVER['REQUEST_URI'];
$arr_uri=explode("/", $uri);
$end_arr=end($arr_uri);
$string=substr($end_arr,0,16);
if ($string!='home_teknisi.php') {
	header("location:../teknisi/home_teknisi.php");
}




?>



<div class="right">
	<div class="row">
		<div class="col-md-12">
			<h3 class="pb-2 text-center">Melihat Data Pekerjaan</h3>		
		</div>
		 
	</div>

	<!-- row table -->
	<div class="row row-table mr-0 ml-0 table-responsive mt-4">
		<div class="col-md-12 p-0 m-0 text-center">
			<table class="table table-striped table-sm table-pekerjaan">
			  <thead>
			    <tr>
			      	<th class="p-2">No</th>
					<th class="p-2">ID Pekerjaan</th>
					<th class="p-2">Tanggal</th>
					<th class="text-left p-2">Nama Custmomer</th>
					<th class="text-left p-2">Nama Barang</th>
					<th class="p-2">Jumlah Barang</th>
			    </tr>
			  </thead>
			  <tbody>			

				<?php
					$no     = 1;					
					$tampil = $pekerjaan->Tampil_Pekerjaan_Utk_Teknisi($user,0);
          			while ($data=$tampil->fetch_object()) :
          				$Tanggal_Pekerjaan = Tampil_Tanggal($data->Tanggal_Pekerjaan);
				 ?>

			    <tr>
			      	<td scope="row"><?php echo $no.'.';?></td>			      
					<td><?php echo $data->Id_Pekerjaan;?> </td>
					<td><?php echo $Tanggal_Pekerjaan;?> </td>
					<td class="text-left"><?php echo $data->Nama_Cust;?> </td>
					<td class="text-left"><?php echo $data->Nama_Barang;?> </td>
					<td><?php echo $data->Jumlah_Barang;?> </td>			     
			    </tr>
			    <?php
			    $no++; 
			    endwhile;
			     ?>			   
			  </tbody>
			</table>
		</div>
	</div>
	<!-- akhir row table -->

	<!-- row cetak -->
	<div class="row">
		<div class="col sm-1 offset-11">
			<a class="btn btn-info" href="cetak_pekerjaan.php" target="_blank">Cetak</a>
		</div>	
	</div>
	<!-- row akhir cetak -->


</div>



   

