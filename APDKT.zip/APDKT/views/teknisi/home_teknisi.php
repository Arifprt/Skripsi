<?php 
include"../../models/+function.php";
require_once("../../config/+koneksi.php");
require_once("../../models/database.php");

$connection = new Database($host, $user, $pass, $database);

Cek_Login("teknisi",$_SESSION['login'],$_SESSION['level']);

?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Halaman Teknisi</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
  </head>
  <body>
   <div class="jumbotron jumbotron-fluid judul">
      <div class="container-fluid">
        <h1 class="display-3">Aplikasi Pengelolah Data Kerja Teknisi<br> PT Komponen Industri dan Teknologi</h1>
      </div>
    </div>

  <section>
    <div class="container-fluid content">
    	<div class="row row-content">
      <!-- slide kiri -->
  		  <div class="col-md-2  slide-left">
  		  	<nav class="navbar navbar-expand-lg  navbar-light rounded">
  			    <button class="navbar-toggler button-menu" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">Menu
  			      <span class="navbar-toggler-icon"></span>
  			    </button>
  			    <div class="collapse navbar-collapse" id="navbarNav">
  			     <ul class="nav flex-column">
      				  <li class="nav-item">
      				    <a class="nav-link active" href="?page=home_teknisi">Home</a>
      				  </li>
      				  <li class="nav-item">
      				    <a class="nav-link" href="?page=melihat_pekerjaan">Melihat Pekerjaan</a>
      				  </li>
      				  <li class="nav-item">
      				    <a class="nav-link" href="?page=membuat_laporan">Membuat Laporan</a>
      				  </li>      				   
  				      <li class="nav-item">
  				        <a class="nav-link" href="?page=logout">Logout</a>
  				      </li>
  				    </ul>
  			    </div>
  			  </nav>					  	
  		  </div>
        <!-- akhir slide kiri -->

        <!-- slide kanan -->
  		  <div class="col-md-9 offset-md-1 slide-right p-3">
          <?php 
            if (@$_GET['page'] == 'home_teknisi' or  @$_GET['page'] == '') {
          ?>
              <h1 align="center" class="selamat-datang"> Selamat Datang di Halaman Teknisi</h1>
          <?php
             }
             else if (@$_GET['page'] == 'logout') {
                echo "<script>
                  alert('Berhasil Logout, Terimakasih')
                  document.location.href='../../index.php'
                </script>"; 
                // menghapus session
                $_SESSION=[];
                session_unset();
                session_destroy();             
             }
              else if (@$_GET['page'] == 'melihat_pekerjaan' ) {
              	include "melihat_pekerjaan.php" ;
              }
              else if (@$_GET['page'] == 'membuat_laporan' ) {
                include "membuat_laporan.php" ;
              }
          ?>

        </div>
        <!-- akhir slide kanan -->
  		</div>
    </div>
  </section>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../../assets/bootstrap/js/jquery-3.3.1.min.js"></script>
    <script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript">
      var url,href,
          link = document.querySelectorAll('.nav-link'); 

      url = window.location.href.split('page=')[1];
      url = url.split('_')[1];
      url = url.split(/&/)[0];

      for (var i =0 ; i < link.length ; i++) {
        href = link[i].getAttribute('href');
        href = href.split('_')[1];

        if ( href==url ) {
          link[i].style.backgroundColor='#007bff';
        }
      }
    </script>
  </body>

</html>