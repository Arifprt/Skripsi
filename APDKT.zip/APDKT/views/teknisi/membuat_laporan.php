<?php
include_once "../../models/+function.php";
include "../../models/m_pekerjaan.php";
include "../../models/m_laporan.php";  

$pekerjaan      = new Pekerjaan($connection);
$laporan        = new laporan($connection);

Cek_Login("teknisi",$_SESSION['login'],$_SESSION['level']);

$teknisi        = $_SESSION['user'];
$id_awal 		= "L" . Pecah_Tgl();
$sql_id         = $laporan->Max_Id($id_awal);
$id             = Max_ID2($sql_id,5,7,'L');

$data_pekerjaan = $pekerjaan->Tampil_Pekerjaan_Utk_Teknisi($teknisi,0);

?>

<div class="right">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Membuat Data Laporan</h3>		
		</div>
	</div>
	<!-- akhir row header -->

	<!-- row form -->	
	<div class="row justify-content-center pt-2">
		<div class="col-sm-6 pl-0 pr-0 ">
			<form class="border border-secondary rounded p-3" action="../../models/proses_membuat_laporan.php" method="POST" name="form_membuat_laporan">

			  <div class="form-group row mb-1">
			    <label for="Id_Laporan" class="col-sm-5 col-form-label font-weight-bold">Id Laporan</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Id_Laporan" id="Id_Laporan" value="<?php echo $id; ?>" required>
			    </div>
			  </div>


			  <div class="form-group row mb-1">
			  	<label for="Id_Pekerjaan" class="col-sm-5 col-form-label font-weight-bold">ID Pekerjaan</label>
			  	<div class="col-sm-7">			  			
					<select  class="custom-select" name="Id_Pekerjaan" id="Id_Pekerjaan" onchange="changeValue(this.value)" required>
						<option value=0 required>-Silahkan Pilih-</option>
						<?php 
							 $jsArray = "var js_pekerjaan = new Array();\n";//menyisipkan script array javascript ke php
							while ($data=$data_pekerjaan->fetch_object()):
						?>

						<option value="<?= $data->Id_Pekerjaan ?>" required> <?= "".$data->Id_Pekerjaan ?>	</option>

						<?php 
								$jsArray .= "js_pekerjaan['" .$data->Id_Pekerjaan . "'] = {nama_customer:'" .
								addslashes($data->Nama_Cust) . "',nama_barang:'".
								addslashes($data->Nama_Barang)."',jumlah:'".addslashes($data->Jumlah_Barang)."'};\n";

							endwhile // $data->nama_database				
						?>								 
									
					</select>
				</div>

			  </div>

			  <div class="form-group row mb-1">
			    <label for="Nama_Customer" class="col-sm-5 col-form-label font-weight-bold">Nama Customer</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Nama_Customer" name="Nama_Customer" required readonly>
			    </div>
			  </div>

			  <div class="form-group row mb-1">
			    <label for="Nama_Barang" class="col-sm-5 col-form-label font-weight-bold">Nama Barang</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Nama_Barang" name="Nama_Barang"  readonly required>
			    </div>
			  </div>

			  <div class="form-group row mb-1">
			    <label for="Jumlah_Barang" class="col-sm-5 col-form-label font-weight-bold">Jumlah Barang</label>
			    <div class="col-sm-7">
			      <input type="number" class="form-control" id="Jumlah_Barang" name="Jumlah_Barang" readonly required>
			    </div>
			  </div>

			  <div class="form-group row mb-1">
				<label for="Permasalahan" class="col-sm-5 col-form-label font-weight-bold">Permasalahan</label>
				    <div class="col-sm-7">
				    	<textarea class="form-control"  name="Permasalahan" id="Permasalahan" rows="2" required></textarea>
				    </div>				    
			  </div>

			   <div class="form-group row mb-1">
				  <label for="Solusi" class="col-sm-5 col-form-label font-weight-bold">Solusi</label>
				  <div class="col-sm-7">
				   		<textarea class="form-control"  name="Solusi" id="Solusi" rows="2" required></textarea>
				  </div>				    
				</div>

			    <div class="form-group row mb-3">
			    <label for="Jumlah_Barang_Selesai" class="col-sm-5 col-form-label font-weight-bold">Jumlah Barang Selesai</label>
			    <div class="col-sm-7">
			      <input type="number" class="form-control" id="Jumlah_Barang_Selesai" name="Jumlah_Barang_Selesai" required>
			    </div>
			  </div>
			  			 
			  	<!-- row button -->
			  <div class="row button justify-content-center">
				<div class="col-sm-w100">
					<input class="btn btn-primary" type="submit" name="Simpan" value="Simpan">
					<input class="btn btn-danger" type="reset" name="Batal" value="Batal">					
				</div>
			  </div>
				<!-- row akhir button -->
			</form>
		</div>
	</div>
	<!-- akhir row form -->
</div>

<script type="text/javascript">
	<?php echo $jsArray;  ?>
	function changeValue(no){
		document.getElementById('Nama_Customer').value = js_pekerjaan[no].nama_customer; 
		document.getElementById('Nama_Barang').value   = js_pekerjaan[no].nama_barang;
		document.getElementById('Jumlah_Barang').value = js_pekerjaan[no].jumlah;
	}; 
</script>