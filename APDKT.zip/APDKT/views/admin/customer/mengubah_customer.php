<?php 
include_once "../../models/+function.php";
include "../../models/m_customer.php";

Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$customer = new Customer($connection);
$id       = $_GET['Id'];
$p        = $_GET['p'];
$sql      = $customer->Cari_Customer($id);

while ($data=$sql->fetch_object()) {
		$id_customer     = $data->Id_Cust;	
		$nama_customer   = $data->Nama_Cust;
		$alamat_customer = $data->Alamat_Cust;
		$telp_customer   = $data->Telp_Cust;
	}

 ?>

<div class="right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Mengubah Data Customer</h3>		
		</div>
	</div>
	<!-- akhir row header -->

	<!-- row form -->	
	<div class="row justify-content-center pt-2">
		<div class="col-sm-6 pl-0 pr-0 ">
			<form class="border border-secondary rounded p-3" action="" method="post" name="form_mengubah_customer">
				<div class="div-close">
					<a href="?page=melihat_customer&p=<?php echo "$p"; ?>" class="close" aria-label="Close">
  						<span aria-hidden="true">&times;</span>
					</a>
				</div>

			  <div class="form-group row ">
			    <label for="Id_Customer" class="col-sm-5 col-form-label font-weight-bold">Id Customer</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Id_Customer" id="Id_Customer" value="<?php echo "$id"; ?>" required>
			    </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Nama_Customer" class="col-sm-5 col-form-label font-weight-bold">Nama Customer</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Nama_Customer" name="Nama_Customer" value="<?php echo "$nama_customer"; ?>" required>
			    </div>
			  </div>

			  <div class="form-group row">
				<label for="Alamat_Customer" class="col-sm-5 col-form-label font-weight-bold">Alamat Customer</label>
				    <div class="col-sm-7">
				    	<textarea class="form-control"  name="Alamat_Customer" id="Alamat_Customer" rows="2" ><?php echo "$alamat_customer"; ?></textarea>
				    </div>				    
			  </div>

			  <div class="form-group row ">
			    <label for="Telp" class="col-sm-5 col-form-label font-weight-bold">Telp</label>
			  	  <div class="col-sm-7">
			     	<input type="tel" class="form-control" id="Telp" name="Telp_Customer" value="<?php echo "$telp_customer"; ?>" required>
			      </div>
			  </div>
			 
			  	<!-- row button -->
			  <div class="row button justify-content-center">
				<div class="col-sm-w100">
					<input class="btn btn-primary" type="submit" name="Simpan" value="Simpan">
					<input class="btn btn-danger" type="reset" name="Batal" value="Batal">					
				</div>
			  </div>
				<!-- row akhir button -->
			</form>
		</div>
	</div>
	<!-- akhir row form -->
</div>

<?php 
if (isset($_POST['Simpan'])) {
	
	$id_customer     = $connection->conn->real_escape_string($_POST['Id_Customer']);
	$nama_customer   = $connection->conn->real_escape_string($_POST['Nama_Customer']);
	$alamat_customer = $connection->conn->real_escape_string($_POST['Alamat_Customer']);
	$telp_customer   = $connection->conn->real_escape_string($_POST['Telp_Customer']);       
	
	$ubah            = $customer->Update_Customer($id_customer,$nama_customer,
													$alamat_customer,$telp_customer);
	
	echo Alert_Ubah($ubah,'home_admin','melihat_customer','mengubah_customer',$p,$id_customer);
    

	
}

 ?>