<?php 
include_once "../../models/+function.php";
require_once("../../config/+koneksi.php");
require_once("../../models/database.php");

$connection = new Database($host, $user, $pass, $database);
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Halaman Admin</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
  </head>
  <body>
    <div class="jumbotron jumbotron-fluid judul">
        <div class="container-fluid">
          <h1 class="display-3">Aplikasi Pengolah Data Kerja Teknisi<br> PT Komponen Industri dan Teknologi</h1>
        </div>
      </div>

    <section>
      <div class="container-fluid content">
      	<div class="row row-content">
        <!-- slide kiri -->
    		  <div class="col-md-2  slide-left">
    		  	<nav class="navbar navbar-expand-lg  navbar-light rounded">
    			    <button class="navbar-toggler button-menu" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">Menu
    			      <span class="navbar-toggler-icon"></span>
    			    </button>
    			    <div class="collapse navbar-collapse" id="navbarNav">
    			     <ul class="nav flex-column">
        				  <li class="nav-item">
        				    <a class="nav-link" href="?page=home_admin">Home</a>
        				  </li>
        				  <li class="nav-item">
        				    <a class="nav-link" href="?page=mengelola_teknisi">Teknisi</a>
        				  </li>
        				  <li class="nav-item">
        				    <a class="nav-link" href="?page=mengelola_customer">Customer</a>
        				  </li>
        				   <li class="nav-item">
  		              <a class="nav-link" href="?page=mengelola_barang">Barang</a>
  		            </li>		            
  		            <li class="nav-item">
  		              <a class="nav-link" href="?page=mengelola_pekerjaan">Pekerjaan</a>
  		            </li>
  		            <li class="nav-item">
  		              <a class="nav-link" href="?page=melihat_laporan">Melihat Laporan</a>
  		            </li>
    				      <li class="nav-item">
    				        <a class="nav-link" href="?page=logout">Logout</a>
    				      </li>
    				    </ul>
    			    </div>
    			  </nav>					  	
    		  </div>
          <!-- akhir slide kiri -->

          <!-- slide kanan -->
    		  <div class="col-md-9 offset-md-1 slide-right ">
          <?php 
                 if (@$_GET['page'] == 'home_admin' or  @$_GET['page'] == '') {
                  ?>
                  <h1 align="center" class="selamat-datang"> Selamat Datang di Halaman Admin</h1>
                  <?php
                 }
                 else if (@$_GET['page'] == 'logout') {
                    echo "<script>
                      alert('Berhasil Logout, Terimakasih')
                      document.location.href='../../index.php'
                    </script>"; 
                    // menghapus session
                    $_SESSION=[];
                    session_unset();
                    session_destroy();             
                 }

                 
                 // ------- bagian menu teknisi --------

                  else if (@$_GET['page'] == 'mengelola_teknisi' ) {
                    include "teknisi/home_admin_teknisi.php" ;
                  }

                  else if (@$_GET['page'] == 'menambah_teknisi') {
                    include "teknisi/menambah_teknisi.php";
                  }

                  else if(@$_GET['page']=='melihat_teknisi'){
                    include "teknisi/melihat_teknisi.php";
                  }

                  else if(@$_GET['page']=='mengubah_teknisi'){
                    include "teknisi/mengubah_teknisi.php";
                  }

                  // ------ bagian customer ---------

                  else if (@$_GET['page'] == 'mengelola_customer' ) {
                    include "customer/home_admin_customer.php" ;
                  } 
                  else if (@$_GET['page'] == 'menambah_customer') {
                    include "customer/menambah_customer.php";
                  }
                  else if(@$_GET['page']=='melihat_customer'){
                    include "customer/melihat_customer.php";
                  }
                  else if(@$_GET['page']=='mengubah_customer'){
                    include "customer/mengubah_customer.php";
                  }


                  // ---------  bagian barang --------------

                  else if (@$_GET['page'] == 'mengelola_barang' ) {
                    include "barang/home_admin_barang.php" ;
                  } 
                  else if (@$_GET['page'] == 'menambah_barang') {
                    include "barang/menambah_barang.php";
                  }
                  else if(@$_GET['page']=='melihat_barang'){
                    include "barang/melihat_barang.php";
                  }
                   else if(@$_GET['page']=='mengubah_barang'){
                    include "barang/mengubah_barang.php";
                  }
                   // ---------  bagian pekerjaan --------------

                  else if (@$_GET['page'] == 'mengelola_pekerjaan' ) {
                    include "pekerjaan/home_admin_pekerjaan.php" ;
                  } 
                   else if (@$_GET['page'] == 'menambah_pekerjaan') {
                    include "pekerjaan/menambah_pekerjaan.php";
                  }
                   else if(@$_GET['page']=='melihat_pekerjaan'){
                    include "pekerjaan/melihat_pekerjaan.php";
                  }
                   else if(@$_GET['page']=='mengubah_pekerjaan'){
                    include "pekerjaan/mengubah_pekerjaan.php";
                  }


                  // --------- bagian melihat laporan ------

                  elseif (@$_GET['page']== 'melihat_laporan') {
                    include "laporan/melihat_laporan.php";
                  }

          ?>
          </div>
          <!-- akhir slide kanan -->
    		</div>
      </div>
    </section>

    <script src="../../assets/bootstrap/js/jquery-3.3.1.min.js"></script>
    <script src="../../assets/bootstrap/js/bootstrap.min.js"></script>

    <script type="text/javascript">
      var url,href,
          link = document.querySelectorAll('.nav-link'); 

      url = window.location.href.split('page=')[1];
      url = url.split('_')[1];
      url = url.split(/&/)[0];

      for (var i =0 ; i < link.length ; i++) {
        href = link[i].getAttribute('href');
        href = href.split('_')[1];

        if ( href==url ) {
          link[i].style.backgroundColor='#007bff';
        }
      }
    </script>
  </body>

</html>