<?php 
include "../../models/m_barang.php";
include_once "../../models/+function.php"; 

Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$barang = new Barang($connection);
$sql_id = $barang->Max_Id();
$id     = Max_Id($sql_id,1,5,'B');

?>



<div class="right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Menambah Data Barang</h3>		
		</div>
	</div>
	<!-- akhir row header -->

	<!-- row form -->	
	<div class="row justify-content-center pt-2">
		<div class="col-sm-6 pl-0 pr-0 ">
			<form class="border border-secondary rounded p-3" action="../../models/proses_menambah_barang.php" method="post" name="form_menambah_barang">

			  <div class="form-group row ">
			    <label for="Id_Barang" class="col-sm-5 col-form-label font-weight-bold">Id Barang</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Id_Barang" id="Id_Barang" value="<?php echo "$id"; ?>" required readonly>
			    </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Nama_Barang" class="col-sm-5 col-form-label font-weight-bold">Nama Barang</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Nama_Barang" name="Nama_Barang" required>
			    </div>
			  </div>

			 
			  	<!-- row button -->
			  <div class="row button justify-content-center">
				<div class="col-sm-w100">
					<input class="btn btn-primary" type="submit" name="Simpan" value="Simpan">
					<input class="btn btn-danger" type="reset" name="Batal" value="Batal">					
				</div>
			  </div>
				<!-- row akhir button -->
			</form>
		</div>
	</div>
	<!-- akhir row form -->
</div>