<?php
include_once "../../models/+function.php"; 
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

?>


<div class="home-menu right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Barang</h3>		
		</div>
		<!-- akhir col header-->
	</div>
	<!-- akhir row header -->
	<div class="row pt-2">
		<div class="col-sm-12">
		<h4>Selamat Datang di Halaman Mengelola Data Barang</h4>
		<a class="btn btn-primary btn-block mt-5" href="?page=menambah_barang" >Menambah Barang</a>
		<a class="btn btn-primary btn-block" href="?page=melihat_barang">Melihat Barang</a>	
		</div>
	</div>
</div>