<?php 
include_once "../../models/+function.php";
include "../../models/m_pekerjaan.php";
include "../../models/m_barang.php";
include "../../models/m_customer.php";
include "../../models/m_teknisi.php";

Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

$pekerjaan    = new Pekerjaan($connection);
$barang       = new Barang($connection);
$customer     = new Customer($connection);
$teknisi      = new teknisi($connection);

$id_awal      = 'P'.Pecah_tgl();
$sql_id       = $pekerjaan->Max_Id($id_awal);
$id           = Max_ID2($sql_id,5,7,'P');
$cek_barang   = $barang->Cek_NM_Barang();
$cek_customer = $customer->Cek_NM_Customer();
$cek_teknisi  = $teknisi->Tampil_Teknisi();

?>





<div class="right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Menambah Data Pekerjaan</h3>		
		</div>
	</div>
	<!-- akhir row header -->

	<!-- row form -->	
	<div class="row justify-content-center pt-2">
		<div class="col-sm-6 pl-0 pr-0 ">
			<form class="border border-secondary rounded p-3" action="../../models/proses_menambah_pekerjaan.php" method="post" name="form_menambah_Pekerjaan">

			  <div class="form-group row ">
			    <label for="Id_Pekerjaan" class="col-sm-5 col-form-label font-weight-bold">Id Pekerjaan</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Id_Pekerjaan" id="Id_Pekerjaan" value="<?php echo "$id"; ?>" required readonly>
			    </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Tanggal_Pekerjaan" class="col-sm-5 col-form-label font-weight-bold">Tanggal Pekerjaan</label>
			    <div class="col-sm-7">
			      <input type="date" class="form-control" id="Tanggal_Pekerjaan" name="Tanggal_Pekerjaan" required>
			    </div>
			  </div>

			  <div class="form-group row">
				<label for="Nama_Customer" class="col-sm-5 col-form-label font-weight-bold">Nama Customer</label>
				    <div class="col-sm-7">
				    	<select class="custom-select" name="Nama_Customer" id="Nama_Customer" required>
							<option value=""> -- Silahkan Pilih  -- </option>
								<?php while ($data_customer=$cek_customer->fetch_object()) :
								?>
							<option value="<?php echo $data_customer->Id_Cust; ?>"><?php echo $data_customer->Nama_Cust; ?></option>
								<?php 
								endwhile;
								?>
						</select>
				    </div>				    
			  </div>

			  <div class="form-group row ">
			    <label for="Nama_Barang" class="col-sm-5 col-form-label font-weight-bold">Nama Barang</label>
			  	  <div class="col-sm-7">
			     	<select class="custom-select" name="Nama_Barang" id="Nama_Barang" required>
						<option value=""> -- Silahkan Pilih  -- </option>
							<?php 
							while ($data_barang=$cek_barang->fetch_object()) :						
							?>
						<option value="<?php echo $data_barang->Id_Barang; ?>"><?php echo $data_barang->Nama_Barang; ?></option>
							<?php 
							endwhile;
						 	?>
					</select>
			      </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Teknisi" class="col-sm-5 col-form-label font-weight-bold">Teknisi</label>
			  	  <div class="col-sm-7">
			     	<select class="custom-select" name="Teknisi" id="Teknisi" required>
						<option value=""> -- Silahkan Pilih  -- </option>
							<?php 
							while ($data_teknisi=$cek_teknisi->fetch_object()) :						
							?>
						<option value="<?php echo $data_teknisi->Id_Teknisi; ?>"><?php echo $data_teknisi->Nama; ?></option>
							<?php 
							endwhile;
						 	?>
					</select>
			      </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Jumlah_Barang" class="col-sm-5 col-form-label font-weight-bold">Jumlah Barang</label>
			    <div class="col-sm-7">
			      <input type="number" class="form-control" id="Jumlah_Barang" name="Jumlah_Barang" required>
			    </div>
			  </div>
			 
			  	<!-- row button -->
			  <div class="row button justify-content-center">
				<div class="col-sm-w100">
					<input class="btn btn-primary" type="submit" name="Simpan" value="Simpan">
					<input class="btn btn-danger" type="reset" name="Batal" value="Batal">					
				</div>
			  </div>
				<!-- row akhir button -->
			</form>
		</div>
	</div>
	<!-- akhir row form -->
</div>

