<div class="home-menu right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Pekerjaan</h3>		
		</div>
		<!-- akhir col header-->
	</div>
	<!-- akhir row header -->
	<div class="row pt-2">
		<div class="col-sm-12">
		<h4>Selamat Datang di Halaman Mengelola Data Pekerjaan</h4>
		<a class="btn btn-primary btn-block mt-5" href="?page=menambah_pekerjaan" >Menambah Pekerjaan</a>
		<a class="btn btn-primary btn-block" href="?page=melihat_pekerjaan">Melihat Rekap Pekerjaan</a>	
		</div>
	</div>
</div>