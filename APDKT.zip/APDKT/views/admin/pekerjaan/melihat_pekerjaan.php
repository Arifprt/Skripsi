<?php 
include_once "../../models/+function.php";

include "../../models/m_pekerjaan.php";
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$pekerjaan = new Pekerjaan($connection);

?>


<div class="right mt-3 mb-3">
	<div class="row">
		<div class="col-md-12">
			<h3 class="pb-2">Melihat Rekap Data Pekerjaan</h3>		
		</div>
		 
	</div>
	<!-- akhir row header -->
	<!-- row cari -->
	<nav class="navbar navbar-light bg-light justify-content-between">
		<span></span>
	    <form method="POST" action="" class="form-inline text-right">
			    <input class="form-control mr-sm-2" type="text" placeholder="Masukan keyword..." name="key" placeholder="keyword pencarian ...." autofocus autocomplete="OFF" 
			    value="<?php if (isset($_REQUEST['key'])) echo $_REQUEST['key'];  ?>">
			    <?php 
			    	if ( isset($_REQUEST['key']) ){
			    ?>
						<a href="?page=melihat_pekerjaan" class="close cari-close" aria-label="Close">
		  					<span aria-hidden="true">&times;</span>
						</a>					
				<?php } ?>
				<button class="btn btn-outline-primary my-2 my-sm-0" type="submit" name="Cari">Cari</button>
		 </form>
	</nav>			

	<!-- akhir row cari -->

	<!-- row table -->
	<div class="row row-table mr-0 ml-0 table-responsive">
		<div class="col-md-12 p-0 m-0 text-center">
			<table class="table table-striped table-sm table-pekerjaan">
			  <thead>
			    <tr>
			      <th>No</th>
			      <th>Id Pekerjaan</th>
			      <th>Tanggal</th>
			      <th class="text-left">Nama Customer</th>
			      <th class="text-left">Nama Barang</th>
			      <th>Jumlah</th>
			      <th>Teknisi</th>
			      <th>Aksi</th>
			    </tr>
			  </thead>
			  <tbody>
			  <?php 
				$JmlDataPerHalaman =5;
				$HalamanAktif      = ( isset($_GET["p"]) ) ? $_GET["p"] : 1;
				$AwalData          = ( $HalamanAktif - 1 ) * $JmlDataPerHalaman;

				// bagian cari
				if (isset($_REQUEST['key']) AND $_REQUEST['key']<>"" ) { 
					$key     = $_REQUEST['key'];
					$tampil  = $pekerjaan->Tampil_Pekerjaan2( $key,$AwalData,$JmlDataPerHalaman );
					$JmlData = mysqli_num_rows( $pekerjaan->Tampil_Pekerjaan2($key,'','') );		
					$no      = $AwalData+1; 
					$link    = "?page=melihat_pekerjaan&key=$key&p=";
					if (isset($_POST['Cari'])){ 
						header("location:../admin/home_admin.php?page=melihat_pekerjaan&key=$key&p=1");
					} 
				}else{
					$tampil  = $pekerjaan->Tampil_Pekerjaan2('',$AwalData,$JmlDataPerHalaman );
					$JmlData = mysqli_num_rows( $pekerjaan->Tampil_pekerjaan2() );
					$no      = $AwalData+1; 
					$link    = "?page=melihat_pekerjaan&p=";
				}

				$p=( isset($_GET["p"]) ) ? $_GET["p"] : 1;
				while ($data=$tampil->fetch_object()) :
					$Tanggal_Pekerjaan = Tampil_Tanggal($data->Tanggal_Pekerjaan);
				 ?>

			    <tr>
			      <td scope="row"><?php echo "$no."; ?></td>			  
				  <td><?php echo $data->Id_Pekerjaan;?></td>
				  <td><?php echo $Tanggal_Pekerjaan;?></td>
				  <td class="text-left"><?php echo $data->Nama_Cust;?></td>
				  <td class="text-left"><?php echo $data->Nama_Barang;?></td>
				  <td><?php echo $data->Jumlah_Barang;?></td>
				  <td><?php echo $data->Username;?></td>
			      <td>
			      	<a class="btn btn-success" href="?page=mengubah_pekerjaan&p=<?php echo "$p"; ?>&Id=<?php echo"$data->Id_Pekerjaan"; ?>" role="button">Ubah</a>
			      	<a class="btn btn-danger" href="?page=melihat_pekerjaan&p=<?php echo "$p"; ?>&Id=<?php echo "$data->Id_Pekerjaan"; ?>&#Hapus" role="button">Hapus</a>
			      </td>
			    </tr>
			    <?php
			    $no++; 
			    endwhile;
			     ?>			   
			  </tbody>
			</table>
		</div>
	</div>
	<!-- akhir row table -->

	<!-- row pagination -->
	<div class="row">
		<div class="col">
			<nav aria-label="..." class="nav">
			    <ul class="pagination">
			      <?php
			         $JmlHalaman=ceil($JmlData / $JmlDataPerHalaman); ?>
			      <li class="page-item <?php $HalamanAktif < 2 ? disabled : ''; ?>">
			          <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif-1; ?>" tabindex="-1">Previous</a>              
			      </li>
			    
			      	<li class="page-item <?php $HalamanAktif<4 ? disabled : ''; ?>">
			            <a class="page-link" href="<?php echo $link ?><?php echo 1; ?>">First</a>
			        </li>

			       <?php
			       
			          for($i=$HalamanAktif-1;$i<$HalamanAktif;$i++):
			             ?>
			                <li class="page-item <?php $i<1 ? disabled :''; ?>">
			                  <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
			                </li>
			            <?php 			           
			          endfor;
			        ?> 

			      <li class="page-item active">
			        <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?><span class="sr-only">(current)</span></a>
			      </li>			      

			      <?php 
			        for($i=$HalamanAktif+1;$i<($HalamanAktif+2);$i++){
			            ?>
			              <li class="page-item <?php $i> $JmlHalaman ? disabled : ''; ?>">
			                <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
			              </li>               
			           <?php 
			            }?>

			        <li class="page-item <?php $HalamanAktif+2>$JmlHalaman ? disabled : ''; ?>">
			            <a class="page-link" href="<?php echo $link ?><?php echo $JmlHalaman; ?>">Last</a>
			        </li>

			        <li class="page-item <?php $HalamanAktif > $JmlHalaman-1 ? disabled : ''; ?>">
			            <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif + 1; ?>">Next</a>
			        </li>
			      
			    </ul>			   
			  </nav>
		</div>	
	</div>
	<!-- row akhir pagination -->


</div>

<!-- popup delete -->

<div class="container-fluid" id="Hapus">
  <div class="row justify-content-center">
    <div class="col-sm-5 hps">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Menghapus Data</h5>
            <a href="?page=melihat_pekerjaan&p=<?php echo $_GET['p']; ?>" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </a>
          </div>
          <div class="modal-body">

            <span> Apakah Anda Yakin Menghapus Data berikut:</span><br><br>
            <?php 
            $Id=$_GET['Id'];
            $tampil=$pekerjaan->Cari_Pekerjaan($Id);
                while ($data=$tampil->fetch_object()) {
               		$id_pekerjaan=$data->Id_Pekerjaan;
					$nama_customer=$data->Nama_Cust;
					$nama_barang=$data->Nama_Barang;
					$teknisi=$data->Nama;        
                  }
             ?>
			<label>Id Pekerjaan</label><span>: <?php echo $id_pekerjaan; ?></span><br>
            <label>Nama Customer</label><span>: <?php echo $nama_customer; ?></span><br>
            <label>Nama Barang</label><span>: <?php echo $nama_barang; ?></span><br>
            <label>Teknisi</label><span>: <?php echo $teknisi; ?></span><br>

          </div>
          <div class="modal-footer">
            <form method="POST" action="">
              <button type="submit" name="hapus_batal" class="btn btn-secondary" data-dismiss="modal">Batal</button>
              <button type="submit" name="hapus" class="btn btn-danger">Hapus</button>
            </form>
          </div>
      	</div>
    </div>
  </div>
</div>

<?php 
if (isset($_POST['hapus'])) {
    	$hapus=$pekerjaan->Delete_pekerjaan($Id);
    	echo Alert_Hapus($hapus,'home_admin','melihat_pekerjaan');
    }
    if (isset($_POST['hapus_batal'])) {
    	echo "<script>
		        document.location.href='#'
		          </script>";
    }
 ?>
