<?php 
include_once "../../models/+function.php";
include "../../models/m_pekerjaan.php";
include "../../models/m_barang.php";
include "../../models/m_customer.php";
include "../../models/m_Teknisi.php";

Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

$pekerjaan = new Pekerjaan($connection);
$barang    = new Barang($connection);
$customer  = new Customer($connection);
$teknisi2  = new Teknisi($connection);

$id        = $_GET['Id'];
$p         = $_REQUEST['p'];

$sql       = $pekerjaan->Cari_Pekerjaan($id);
while ($data=$sql->fetch_object()) {
	$id_pekerjaan  = $data->Id_Pekerjaan;
	$tanggal       = $data->Tanggal_Pekerjaan;
	$nama_cust     = $data->Nama_Cust;
	$nama_barang   = $data->Nama_Barang;
	$teknisi       = $data->Id_Teknisi;
	$jumlah_barang = $data->Jumlah_Barang;
}
$cek_barang   = $barang->Cek_NM_Barang();
$cek_customer = $customer->Cek_NM_Customer();
$cek_teknisi  = $teknisi2->Tampil_Teknisi();

?>

<div class="right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Mengubah Data Pekerjaan</h3>		
		</div>
	</div>
	<!-- akhir row header -->

	<!-- row form -->	
	<div class="row justify-content-center pt-2">
		<div class="col-sm-6 pl-0 pr-0 ">
			<form class="border border-secondary rounded p-3" action="" method="post" name="form_mengubah_pekerjaan">
				<div class="div-close">
					<a href="?page=melihat_pekerjaan&p=<?php echo "$p"; ?>" class="close" aria-label="Close">
  						<span aria-hidden="true">&times;</span>
					</a>
				</div>

			  <div class="form-group row ">
			    <label for="Id_Pekerjaan" class="col-sm-5 col-form-label font-weight-bold">Id Pekerjaan</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Id_Pekerjaan" id="Id_Pekerjaan" value="<?php echo "$id"; ?>" required>
			    </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Tanggal_Pekerjaan" class="col-sm-5 col-form-label font-weight-bold">Tanggal Pekerjaan</label>
			    <div class="col-sm-7">
			      <input type="date" class="form-control" id="Tanggal_Pekerjaan" name="Tanggal_Pekerjaan"  value="<?php echo $tanggal; ?>" required>
			    </div>
			  </div>

			  <div class="form-group row">
				<label for="Nama_Customer" class="col-sm-5 col-form-label font-weight-bold">Nama Customer</label>
				    <div class="col-sm-7">
				    	<select class="custom-select" name="Nama_Customer" id="Nama_Customer" required>
							<option value=""> -- Silahkan Pilih  -- </option>
								<?php while ($data_customer=$cek_customer->fetch_object()) :
								?>
							<option value="<?php echo $data_customer->Id_Cust;?>" 
									<?php 
										if ($data_customer->Nama_Cust==$nama_cust) { echo "selected=\"selected\"";}
									?> ><?php echo "$data_customer->Nama_Cust";?>  
							</option>
								<?php 
								endwhile;
								?>
						</select>
				    </div>				    
			  </div>

			 <div class="form-group row ">
			    <label for="Nama_Barang" class="col-sm-5 col-form-label font-weight-bold">Nama Barang</label>
			  	  <div class="col-sm-7">
			     	<select class="custom-select" name="Nama_Barang" id="Nama_Barang" required>
						<option value=""> -- Silahkan Pilih  -- </option>
							<?php 
							while ($data_barang=$cek_barang->fetch_object()) :						
							?>
						<option value="<?php echo $data_barang->Id_Barang;?>" 
								<?php 
									if ($data_barang->Nama_Barang==$nama_barang) { echo "selected=\"selected\"";}
								?> ><?php echo "$data_barang->Nama_Barang";?>  
						</option>
							<?php 
							endwhile;
						 	?>
					</select>
			      </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Teknisi" class="col-sm-5 col-form-label font-weight-bold">Teknisi</label>
			  	  <div class="col-sm-7">
			     	<select class="custom-select" name="Teknisi" id="Teknisi" required>
						<option value=""> -- Silahkan Pilih  -- </option>
							<?php 
							while ($data_teknisi=$cek_teknisi->fetch_object()) :					
							?>
						<option value="<?php echo $data_teknisi->Id_Teknisi;?>" 
								<?php 
									if ($data_teknisi->Id_Teknisi==$teknisi) { echo "selected=\"selected\"";}
								?> ><?php echo "$data_teknisi->Nama";?>  
						</option>
							<?php 
							endwhile;
						 	?>
					</select>
			      </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Jumlah_Barang" class="col-sm-5 col-form-label font-weight-bold">Jumlah Barang</label>
			    <div class="col-sm-7">
			      <input type="number" class="form-control" id="Jumlah_Barang" name="Jumlah_Barang" value="<?php echo "$jumlah_barang"; ?>" required>
			    </div>
			  </div>
			 
			  	<!-- row button -->
			  <div class="row button justify-content-center">
				<div class="col-sm-w100">
					<input class="btn btn-primary" type="submit" name="Simpan" value="Simpan">
					<input class="btn btn-danger" type="reset" name="Batal" value="Batal">					
				</div>
			  </div>
				<!-- row akhir button -->
			</form>
		</div>
	</div>
	<!-- akhir row form -->
</div>

<?php 
if (isset($_POST['Simpan'])) {

	$id_pekerjaan      = $connection->conn->real_escape_string($_POST['Id_Pekerjaan']);
	$tanggal_pekerjaan = $connection->conn->real_escape_string($_POST['Tanggal_Pekerjaan']);
	$nama_customer     = $connection->conn->real_escape_string($_POST['Nama_Customer']);
	$nama_barang       = $connection->conn->real_escape_string($_POST['Nama_Barang']);
	$teknisi           = $connection->conn->real_escape_string($_POST['Teknisi']);
	$jumlah_barang     = $connection->conn->real_escape_string($_POST['Jumlah_Barang']);
	
	$ubah              = $pekerjaan->Update_Pekerjaan($id_pekerjaan,$tanggal_pekerjaan,$nama_customer,
														$nama_barang,$teknisi,$jumlah_barang);


    echo Alert_Ubah($ubah,'home_admin','melihat_pekerjaan','mengubah_pekerjaan',$p,$id_pekerjaan);
}

?>