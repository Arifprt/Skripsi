<?php
// session_start();
include_once "../../../models/+function.php"; 
require_once("../../../config/+koneksi.php");
require_once("../../../models/database.php");
require_once('../../../assets//html2pdf/html2pdf.class.php');
include "../../../models/m_pekerjaan.php"; 
include "../../../models/m_laporan.php";
include "../../../models/m_teknisi.php";
$connection = new Database($host, $user, $pass, $database);
$pekerjaan  = new Pekerjaan($connection);
$laporan    = new laporan($connection);
$teknisi = new Teknisi($connection);

$date       = date('d-m-Y');
$key        = $_SESSION['key'];
$tgl_awal   = $_SESSION['tgl_awal'];
$tgl_akhir  = $_SESSION['tgl_akhir'];
$k_cust  = $_SESSION['k_cust'];
$d_akhir  = $_SESSION['d_akhir'];


$source='
<style>
	*{
		padding: 0; 
		margin: 0;

	}
	.container{
		
		width:1080px;
		margin:10px auto;

	}
	.header-pdf{
		padding: 10px;
		text-align: center;
		font-size: 11px;
		border-bottom: 2px solid rgba(0,0,0,0.8);
		margin-bottom: 15px;
	}

	.contain-pdf{
		padding: 2px;
	}


	.contain-pdf-header{
		margin-bottom: 10px;
	}
	.contain-pdf-header h2{
		text-align: center;
		margin-bottom: 15px;
	}

	.contain-pdf-header p{
		font-size: 15px;
		padding: 3px;
	}
	.contain-table-pdf{
		text-align: center;
		padding: 10px;
	}

	.contain-table-pdf table{
		border: 1px solid black;
		border-radius: 2px;
		margin: auto;
		margin-top: 40px;
		font-size: 15px;
	}

	.contain-table-pdf table th{
		text-align: center;
		padding: 8px 8px;
		background-color: #ddd;
	}

	.contain-table-pdf table td{
		text-align: center;
		padding: 10px 15px;

	}

</style> ';


$source .= '
<page>
	<div class="container">
		<div class="header-pdf">
		<h1>Aplikasi Pengolah Data Kerja Teknisi<br>
		PT. Komponen Industri dan Teknologi</h1>	

		</div>

		<div class="contain-pdf">
			<div class="contain-pdf-header">
				<h2>Laporan Kerja Teknisi </h2>
				<p>Tanggal : '.$date.'</p>
				<p>Teknisi :';
				


          		$tampil2=$laporan->Laporan_NM_Teknisi( $key,$tgl_awal,$tgl_akhir,true,$k_cust );
				while ( $data2 = $tampil2->fetch_object()) {;
 
 $source.='  '.$data2->Nama.', ';
				}

$source.=' </p>
			</div>

			<div class="contain-table-pdf">
				<table>
					<tr>
						<th>NO</th>
						<th>Tanggal</th>
						<th>Teknisi</th>
						<th>Nama Customer</th>
						<th>Nama Barang</th>
						<th>Jumlah Barang</th>
						<th>Selesai</th>
						<th>Belum Selesai</th>

					</tr>';
					$no=1;					
          			$tampil=$laporan->Tampil_Laporan_Admin( $key,$tgl_awal,$tgl_akhir,'','','',$k_cust,$d_akhir,'true' );
          			while ($data = $tampil->fetch_object()) {
          				$jml_brg=$data->Jml_Brg_Blm_Selesai+$data->Jml_Brg_Selesai;
          				$tanggal=Tampil_Tanggal($data->Tgl_Laporan);


			$source.= '<tr>
						<td>'.$no++.'.</td>
						<td>'.$tanggal.'</td>
						<td text-align="left">'.$data->Nama.'</td>
						<td text-align="left">'.$data->Nama_Cust.'</td>
						<td text-align="left">'.$data->Nama_Barang.'</td>
						<td>'.$jml_brg.'</td>
						<td>'.$data->Jml_Brg_Selesai.'</td>
						<td>'.$data->Jml_Brg_Blm_Selesai.'</td>
					  </tr>';
					 }
			

		$source.='</table>
			</div>
		</div>
	</div>
</page>';

$html2pdf = new HTML2PDF('L', 'A4', 'en');
$html2pdf->setDefaultFont('Arial');
$html2pdf->writeHTML($source);
$html2pdf->Output('Pekerjaan - '.rand().'.pdf');

?>