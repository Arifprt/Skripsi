<?php 
include_once "../../models/+function.php";
include "../../models/m_laporan.php";
include "../../models/m_teknisi.php";
ob_start(); // utk error cannot modify header information


Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

$laporan = new Laporan($connection);
$teknisi = new Teknisi($connection);
$cek_teknisi  = $teknisi->Tampil_Teknisi();
$cek_customer = $laporan->Tampil_Laporan_Admin('','','','','','order');
$key_teknisi= ( isset($_REQUEST["key"]) ) ? $_REQUEST["key"] : null;
$k_cust= ( isset($_REQUEST["k_cust"]) ) ? $_REQUEST["k_cust"] : null;
Hapus_Session();
?>

<div class="right ">
	<!-- row utk cari -->
	<div class="row row-form-cari p-3 ">
		<div class="col border border-secondary rounded bg-light p-3">
			<form action="" method="POST" name="Form-cari-laporan">
				<div class="form-group row ">
				    <label for="key" class="col-sm-1 col-form-label ">Teknisi</label>
				  	  <div class="col-sm-3">
				     	<select class="custom-select" name="key" id="key" >
							<option value=""> -- Silahkan Pilih  -- </option>
								<?php 
							while ($data_teknisi=$cek_teknisi->fetch_object()) :						
								?>
							<option value="<?php echo $data_teknisi->Id_Teknisi; ?>"
								<?php
				                  if ($key_teknisi==$data_teknisi->Id_Teknisi): 
				                    echo "selected";
				                  endif 
				                  ?>>								
								<?php echo $data_teknisi->Nama; ?>									
							</option>
							<?php 
							endwhile;
							?>
						</select>
				      </div>

				      <label for="k_cust" class="col-sm-2 col-form-label ">Customer</label>
				  	  <div class="col-sm-3">
				     	<select class="custom-select" name="k_cust" id="k_cust" >
							<option value=""> -- Silahkan Pilih  -- </option>
								<?php 
								while ($data_customer=$cek_customer->fetch_object()) :						
								?>
							<option value="<?php echo $data_customer->Nama_Cust; ?>"
								<?php
				                  if ($k_cust==$data_customer->Nama_Cust): 
				                    echo "selected";
				                  endif 
				                  ?>>								
								<?php echo $data_customer->Nama_Cust; ?>
									
							</option>
								<?php 
								endwhile;
							 	?>
						</select>						
				      </div>
				      <div class="col-sm-3 text-center pl-3 align-self-center">
				        <label class="form-check-label" for="d_akhir">
				        	<input class="form-check-input" type="checkbox" name="d_akhir"   checked="checked">
				          <input class="form-check-input" type="checkbox" name="d_akhir"  id="d_akhir" value="cek"> Data Terakhir
				        </label>
				      </div>

			  	</div>
	

				<div class="form-group row mb-0">
					<label for="Periode" class="col-sm-1 col-form-label ">Periode</label>
				    <div class="col-sm-3">
				      <input type="date" name="Tanggal_Awal" class="form-control" id="Tanggal_Awal">
				    </div>
				    <label for="s/d" class="col-sm-2 col-form-label text-left">s/d</label>
				    <div class="col-sm-3 mb-1">
				      <input type="date" name="Tanggal_Akhir" class="form-control" id="Tanggal_Akhir">
				    </div>
				    <div class="col-sm-3 text-md-center">
				    	<button type="submit" class="btn btn-outline-primary w-75 p-1" name="Cari">Cari</button>   	
				    </div>
				</div>
			</form>
		</div>
	</div>

	<?php 
	 ?>
	<!-- akhir row utk cari -->
	<!-- row table laporan -->
	<div class="row">
		<div class="col">
			<table class="table table-striped table-responsive table-laporan text-center ">
			  <thead>
			    <tr>
			      <th>No.</th>
			      <th>Id Laporan</th>
			      <th>Tanggal</th>
			      <th class ="text-left">Teknisi</th>
			      <th class="text-left">Customer</th>
			      <th class="text-left">Barang</th>
			      <th>Jumlah Selesai</th>
			      <th>Jumlah Belum Selesai</th>
			    </tr>
			  </thead>
			  <tbody>
			   <?php 
					$JmlDataPerHalaman = 5;
					$HalamanAktif      = ( isset($_GET["p"]) ) ? $_GET["p"] : 1;
					$AwalData          = ( $HalamanAktif - 1 ) * $JmlDataPerHalaman;

				// bagian cari
				if ( (isset($_REQUEST['k_cust']) AND $_REQUEST['k_cust'] <> "") OR 
					 (isset($_REQUEST['key']) AND $_REQUEST['key']<>"") OR 
					 (isset($_REQUEST['Tanggal_Awal']) AND $_REQUEST['Tanggal_Awal']<>"") OR 
					 (isset($_REQUEST['Tanggal_Akhir']) AND $_REQUEST['Tanggal_Akhir']<>"") OR
					 (isset($_REQUEST['d_akhir']) AND $_REQUEST['d_akhir'] <> "")  )  { 
					$key       = $_REQUEST['key'];
					$k_cust    = $_REQUEST['k_cust'];
					$tgl_awal  = $_REQUEST['Tanggal_Awal'];
					$tgl_akhir = $_REQUEST['Tanggal_Akhir'];//
					$d_akhir 	= ($_REQUEST['d_akhir'])=='cek' ? $_REQUEST['d_akhir'] : null;

					if ( $tgl_awal>$tgl_akhir ) {
						echo "<script>
		           				alert('format tanggal salah !!')
		           				document.location.href='../admin/home_admin.php?page=melihat_laporan'
		          	  		  </script>";
		          	  die();
					}

					$tampil       = $laporan->Tampil_Laporan_Admin( $key,$tgl_awal,$tgl_akhir,$AwalData,$JmlDataPerHalaman,
									'',$k_cust,$d_akhir );
					$JmlData      = mysqli_num_rows( $laporan->Tampil_Laporan_Admin($key,$tgl_awal,$tgl_akhir,'','',
									'',$k_cust,$d_akhir) );
					$no           = $AwalData+1; // no untuk di table
					$link         = "?page=melihat_laporan&key=$key&k_cust=$k_cust&Tanggal_Awal=$tgl_awal&Tanggal_Akhir=$tgl_akhir&d_akhir=$d_akhir&p=";
					if (isset($_POST['Cari'])){ 
						header("location:../admin/home_admin.php?page=melihat_laporan&key=$key&k_cust=$k_cust&Tanggal_Awal=$tgl_awal&Tanggal_Akhir=$tgl_akhir&d_akhir=$d_akhir&p=1");
					} 
					$_SESSION['key']       = $key;
					$_SESSION['tgl_awal']  = $tgl_awal;
					$_SESSION['tgl_akhir'] = $tgl_akhir;
					$_SESSION['k_cust']    = $k_cust;
					$_SESSION['d_akhir']   = $d_akhir;
				}else{
					$tampil  = $laporan->Tampil_Laporan_Admin('','','',$AwalData,$JmlDataPerHalaman);
					$JmlData = mysqli_num_rows( $laporan->Tampil_Laporan_Admin() );
					$no      = $AwalData+1; 
					$link    = "?page=melihat_laporan&p=";
				}

				while ($data=$tampil->fetch_object() ) :
					$tanggal=Tampil_Tanggal($data->Tgl_Laporan);
				?>
			    <tr>
					<th scope ="row"><?php echo "$no."; ?></th>
					<td><?php echo $data->Id_Laporan; ?></td>
					<td><?php echo Tampil_Tanggal($data->Tgl_Laporan); ?></td>
					<td class ="text-left"><?php echo $data->Nama; ?></td>
					<td class ="text-left"><?php echo $data->Nama_Cust; ?></td>
					<td class ="text-left"><?php echo $data->Nama_Barang; ?></td>
					<td><?php echo $data->Jml_Brg_Selesai; ?></td>
					<td><?php echo $data->Jml_Brg_Blm_Selesai; ?></td>
			    </tr>

			    <?php 
				$no++;
				endwhile;
				?>			   
			  </tbody>
			</table>
		</div>		
	</div>



	<div class="row">
		<div class="col-sm-10 ">
			<nav aria-label="..." class="nav">
			    <ul class="pagination">
			      <?php
			         $JmlHalaman=ceil($JmlData / $JmlDataPerHalaman); ?>
			      <li class="page-item <?php $HalamanAktif < 2 ? disabled : ''; ?>">
			          <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif-1; ?>" tabindex="-1">Previous</a>              
			      </li>
			    
			      	<li class="page-item <?php $HalamanAktif<4 ? disabled : ''; ?>">
			            <a class="page-link" href="<?php echo $link ?><?php echo 1; ?>">First</a>
			        </li>

			       <?php			       
			          for($i=$HalamanAktif-1;$i<$HalamanAktif;$i++):
			             ?>
			                <li class="page-item <?php $i<1 ? disabled :''; ?>">
			                  <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
			                </li>
			            <?php 			           
			          endfor;
			        ?> 

			      <li class="page-item active">
			        <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?><span class="sr-only">(current)</span></a>
			      </li>			      

			      <?php 
			        for($i=$HalamanAktif+1;$i<($HalamanAktif+2);$i++){
			            ?>
			              <li class="page-item <?php $i> $JmlHalaman ? disabled : ''; ?>">
			                <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
			              </li>               
			           <?php 
			            }?>

			        <li class="page-item <?php $HalamanAktif+2>$JmlHalaman ? disabled : ''; ?>">
			            <a class="page-link" href="<?php echo $link ?><?php echo $JmlHalaman; ?>">Last</a>
			        </li>

			        <li class="page-item <?php $HalamanAktif > $JmlHalaman-1 ? disabled : ''; ?>">
			            <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif + 1; ?>">Next</a>
			        </li>
			      
			    </ul>			   
			  </nav>
		</div>
		<!-- cetak -->
		<div class="col-sm-2 text-md-right col-cetak">
			<a href="laporan/cetak_laporan.php" class="btn btn-primary btn-cetak w-75" target="_blank">Cetak</a>
		</div>
		<!-- akhir cetak  -->
	</div>
	<!-- row akhir pagination -->

</div>

<script type="text/javascript">
	const tgl_awal  = document.querySelector('#Tanggal_Awal');
	const tgl_akhir = document.querySelector('#Tanggal_Akhir');
	tgl_awal.addEventListener('input', function(){
		var value = tgl_awal.value;
		if (value != '') {
			tgl_akhir.setAttribute('required','required');
		}
	})
	tgl_akhir.addEventListener('input', function(){
		var value = tgl_akhir.value;
		if (value != '') {
			tgl_awal.setAttribute('required','required');
		}
	})
</script>