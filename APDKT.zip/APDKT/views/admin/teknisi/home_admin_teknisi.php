<div class="home-menu right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Teknisi</h3>		
		</div>
		<!-- akhir col header-->
	</div>
	<!-- akhir row header -->
	<div class="row pt-2">
		<div class="col-sm-12">
		<h4>Selamat Datang di Halaman Mengelola Data Teknisi</h4>
		<a class="btn btn-primary btn-block mt-5" href="?page=menambah_teknisi" role="button">Menambah Teknisi</a>
		<a class="btn btn-primary btn-block" href="?page=melihat_teknisi" role="button">Melihat Teknisi</a>	
		</div>
	</div>
</div>