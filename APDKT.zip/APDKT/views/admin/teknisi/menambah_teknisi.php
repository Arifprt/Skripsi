<?php 
include_once "../../models/+function.php";
include "../../models/m_teknisi.php";

Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$teknisi  = new Teknisi($connection);
$sql_id   = $teknisi->Max_Id();
$id       = Max_Id($sql_id,1,5,'T');	

?>


<div class="right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Menambah Data Teknisi</h3>		
		</div>
	</div>
	<!-- akhir row header -->

	<!-- row form -->	
	<div class="row justify-content-center pt-2">
		<div class="col-sm-6 pl-0 pr-0 ">
			<form class="border border-secondary rounded p-3" action="../../models/proses_menambah_teknisi.php" method="post" name="form_menambah_teknisi">
			  <div class="form-group row ">
			    <label for="Id_Teknisi" class="col-sm-5 col-form-label font-weight-bold">Id Teknisi</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Id_Teknisi" id="Id_Teknisi" value="<?php echo "$id"; ?>" required>
			    </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Nama" class="col-sm-5 col-form-label font-weight-bold">Nama</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Nama_Teknisi" id="Nama" required>
			    </div>
			  </div>
			  <div class="form-group row ">
			    <label for="Username" class="col-sm-5 col-form-label font-weight-bold">Username</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Username" name="Username" required>
			    </div>
			  </div>
			   <div class="form-group row ">
			    <label for="Password" class="col-sm-5 col-form-label font-weight-bold">Password</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Password" name="Password" required>
			    </div>
				</div>
			    
			    <div class="form-group row ">
			    	<label for="Level" class="col-sm-5 col-form-label font-weight-bold">Level</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Level" name="Level" required value="teknisi">
			    </div>
			  </div>
			 
			  	<!-- row button -->
			  <div class="row button justify-content-center">
				<div class="col-sm-w100">
					<input class="btn btn-primary" type="submit" name="Simpan" value="Simpan">
					<input class="btn btn-danger" type="reset" name="Batal" value="Batal">					
				</div>
			  </div>
				<!-- row akhir button -->
			</form>
		</div>
	</div>
	<!-- akhir row form -->
	
</div>