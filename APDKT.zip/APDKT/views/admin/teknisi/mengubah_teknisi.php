<?php 
include_once "../../models/+function.php";
include "../../models/m_teknisi.php";

Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

$teknisi   = new Teknisi($connection);

$Id     = $_GET['Id'];
$p      = $_GET['p'];

$update = $teknisi->Cari_Teknisi($Id);
while ($data=$update->fetch_object()) {
		$nama     = $data->Nama;	
		$username = $data->Username;
		$pass     = $data->Password;
		$level    = $data->Level;
	} 
?>



<div class="right mt-3 mb-3">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="pb-2">Mengubah Data Teknisi</h3>		
		</div>
	</div>
	<!-- akhir row header -->

	<!-- row form -->	
	<div class="row justify-content-center pt-2">
		<div class="col-sm-6 pl-0 pr-0">
			<form class="border border-secondary rounded p-3" action="" method="POST" name="form_mengubah_user">
			<div class="div-close">
				<a href="?page=melihat_teknisi&p=<?php echo "$p"; ?>" class="close" aria-label="Close">
  					<span aria-hidden="true">&times;</span>
				</a>
			</div>
			<div class="form-group row mt-2">
			    <label for="Id" class="col-sm-5 col-form-label font-weight-bold">Id Teknisi</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Id" id="Id_Teknisi"  value="<?php echo $Id;?>" required>
			    </div>
			  </div>
			  <div class="form-group row mt-2">
			    <label for="Nama" class="col-sm-5 col-form-label font-weight-bold">Nama</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" name="Nama_User" id="Nama"  value="<?php echo $nama;?>" required>
			    </div>
			  </div>
			  <div class="form-group row ">
			    <label for="Username" class="col-sm-5 col-form-label font-weight-bold">Username</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Username" name="Username" value="<?php echo $username;?>" required>
			    </div>
			  </div>
			   <div class="form-group row ">
			    <label for="Password" class="col-sm-5 col-form-label font-weight-bold">Password</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Password" name="Password" required value="<?php echo $pass;?>">
			    </div>
			  </div>

			  <div class="form-group row ">
			    <label for="Level" class="col-sm-5 col-form-label font-weight-bold">Level</label>
			    <div class="col-sm-7">
			      <input type="text" class="form-control" id="Level" name="Level" required value="<?php echo $level ?>">
			    </div>
			  </div>
			  	<!-- row button -->
			  <div class="row button justify-content-center">
				<div class="col-sm-w100">
				<input class="btn btn-primary" type="submit" name="Simpan" value="Simpan">
				<input class="btn btn-danger" type="reset" name="Batal" value="Batal">					
				</div>
			  </div>
				<!-- row akhir button -->
			</form>
		</div>
	</div>
	<!-- akhir row form -->
	
</div>



<?php 
if (isset($_POST['Simpan'])) {

	$Id 	  = $connection->conn->real_escape_string($_POST['Id']);
	$username = $connection->conn->real_escape_string($_POST['Username']);
	$nama     = $connection->conn->real_escape_string($_POST['Nama_User']);
	$pass     = $connection->conn->real_escape_string($_POST['Password']);
	$level    = $connection->conn->real_escape_string($_POST['Level']);
	
	$ubah     = $teknisi->Update_Teknisi($Id,$nama,$username,$pass,$level);
	
	echo Alert_Ubah($ubah,'home_admin','melihat_teknisi','mengubah_teknisi',$p,$Id); 
					
		
	
}

?>