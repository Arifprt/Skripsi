<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Halaman Login</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>

  <section>
  	<div class="container-fluid bg-secondary container-login">
  		<div class="row justify-content-center row-login">
    		<div class="col-sm-3 bg-white text-gray-dark  rounded p-3">
    			<form method="POST" action="models/proses_login.php" name="form-login">
      			<h2 class="text-center mb-4">Halaman Login</h2>
    			  <div class="form-group">
    			    <label for="Username" class="font-weight-bold">Username</label>
    			    <input type="text" class="form-control" id="Username" name="Username" autofocus>			 
    			  </div>
    			  <div class="form-group">
    			    <label for="Password" class="font-weight-bold">Password</label>
    			    <input type="password" class="form-control" id="Password" name="Password">
    			  </div>			 
    			  <button type="submit" class="btn btn-primary w-100" name="Login">Login</button>
    			</form>
    		</div>
    	</div>
  	</div>
  </section>




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>

</html>